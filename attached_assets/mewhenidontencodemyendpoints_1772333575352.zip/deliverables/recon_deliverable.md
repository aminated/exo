# Reconnaissance Deliverable: exogenous.fun

## 0) HOW TO READ THIS
This reconnaissance report provides a comprehensive map of the application's attack surface, with special emphasis on authorization and privilege escalation opportunities for the Authorization Analysis Specialist.

**Key Sections for Authorization Analysis:**
- **Section 4 (API Endpoint Inventory):** Contains authorization details for each endpoint - focus on "Required Role" and "Object ID Parameters" columns to identify IDOR candidates.
- **Section 6.4 (Guards Directory):** Catalog of authorization controls - understand what each guard means before analyzing vulnerabilities.
- **Section 7 (Role & Privilege Architecture):** Complete role hierarchy and privilege mapping - use this to understand the privilege lattice and identify escalation targets.
- **Section 8 (Authorization Vulnerability Candidates):** Pre-prioritized lists of endpoints for horizontal, vertical, and context-based authorization testing.

**How to Use the Network Mapping (Section 6):** The entity/flow mapping shows system boundaries and data sensitivity levels. Pay special attention to flows marked with authorization guards and entities handling PII/sensitive data.

**Priority Order for Testing:** Start with Section 8's High-priority horizontal candidates, then vertical escalation endpoints for each role level, finally context-based workflow bypasses.

## 1. Executive Summary

**Application Purpose:** exogenous.fun is an e-commerce platform for supplement testing services, offering both physical supplement products and laboratory testing services for customer-submitted samples. The application processes cryptocurrency payments (Bitcoin, Litecoin, Monero) via BTCPay Server integration and publishes test results publicly.

**Core Technology Stack:**
- **Frontend:** React 18.3.1 with TypeScript, Vite build system, TanStack Query for data fetching, shadcn/ui component library
- **Backend:** Node.js with Express 5.0.1, TypeScript, Drizzle ORM
- **Database:** PostgreSQL with session storage via connect-pg-simple
- **Infrastructure:** Likely hosted on Replit (based on .replit configuration), uses BTCPay Server for cryptocurrency payment processing
- **CDN/Security:** Cloudflare (based on /cdn-cgi/rum endpoints observed in network traffic)

**Primary User-Facing Components:**
- Product catalog with shopping cart functionality
- Cryptocurrency checkout flow (BTC/LTC/XMR)
- Public test results database (searchable by UID)
- Blog/musings section with optional password-protected posts
- Admin panel for content management (products, posts, test results, orders, coupons)
- Site page management (dynamic content pages like banner and terms)

**Authentication Model:** Single admin account (no user registration), session-based authentication with PostgreSQL storage, 7-day session lifetime.

## 2. Technology & Service Map

### Frontend Technologies
- **Framework:** React 18.3.1 with TypeScript 5.6.2
- **Build Tool:** Vite 5.4.2
- **Routing:** Wouter 3.3.5 (lightweight React router)
- **State Management:** TanStack Query v5 (React Query) for server state
- **UI Library:** shadcn/ui (Radix UI primitives with Tailwind CSS)
- **Form Handling:** React Hook Form 7.53.0 with Zod validation
- **Styling:** Tailwind CSS 3.4.1
- **Key Dependencies:**
  - recharts (charting for admin analytics)
  - nanoid (ID generation)
  - date-fns (date formatting)

### Backend Technologies
- **Runtime:** Node.js
- **Framework:** Express 5.0.1
- **Language:** TypeScript 5.6.2
- **ORM:** Drizzle ORM 0.36.4 with drizzle-zod for schema validation
- **Database Driver:** pg (node-postgres) 8.13.1
- **Session Management:** express-session 1.18.1 with connect-pg-simple 10.0.0
- **File Upload:** multer 1.4.5-lts.1 (memory storage, 10MB limit)
- **Rate Limiting:** express-rate-limit 7.4.1
- **Key Dependencies:**
  - zod (runtime validation)
  - dotenv (environment configuration)

### Infrastructure & External Services
- **Database:** PostgreSQL (connection via DATABASE_URL environment variable)
- **Payment Gateway:** BTCPay Server (self-hosted cryptocurrency payment processor)
  - Supports Bitcoin (BTC), Litecoin (LTC), Monero (XMR)
  - Configuration via BTCPAY_URL, BTCPAY_API_KEY, BTCPAY_STORE_ID
- **CDN:** Cloudflare (inferred from /cdn-cgi/rum endpoints)
- **Hosting:** Likely Replit-based deployment (based on .replit configuration file)

### Identified Subdomains
**No subdomains discovered.** The application operates on a single domain: exogenous.fun

### Open Ports & Services
**External scan data not provided.** Based on application configuration:
- **HTTP/HTTPS:** Port 443 (HTTPS via Cloudflare)
- **Application Server:** Likely runs on port 5000 internally (based on server configuration)
- **Database:** PostgreSQL port 5432 (internal only, not exposed)

**Note:** Session cookies configured with `secure: false` in code, indicating the application may accept HTTP connections (security concern).

## 3. Authentication & Session Management Flow

### Entry Points
- **Primary Entry Point:** `/admin` - Admin login page
  - File: `/repos/exo/client/src/pages/admin.tsx` (lines 11-65)
  - Endpoint: `POST /api/admin/login` (server/routes.ts lines 124-135)
- **Secondary Authentication:** `/api/posts/:slug/unlock` - Password-protected blog posts
  - File: `/repos/exo/server/routes.ts` (lines 107-122)

**Critical Finding:** There is NO user registration or public user authentication system. The application only supports a single admin account configured via environment variables.

### Mechanism: Session-Based Authentication with PostgreSQL Storage

**Step-by-Step Authentication Process:**

1. **Admin Access Check** (`GET /api/admin/check`)
   - Admin page loads and queries `/api/admin/check` (client/pages/admin.tsx line 1747)
   - Server checks if `req.session.isAdmin === true` (server/routes.ts lines 143-145)
   - Returns `{ isAdmin: boolean }`
   - If false, displays login form; if true, renders admin panel

2. **Credential Submission** (`POST /api/admin/login`)
   - User enters username and password in login form
   - Client submits via `apiRequest("POST", "/api/admin/login", { username, password })`
   - **CRITICAL SECURITY ISSUE:** Credentials compared in PLAIN TEXT
   - Code: `if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD)` (line 129)
   - Credentials stored in environment variables: `ADMIN_USERNAME`, `ADMIN_PASSWORD`
   - **EXPOSED CREDENTIALS:** Admin password visible in `.replit` file: `"Ju%5uLB@98B*mPsRGDszSy9A"`

3. **Session Generation**
   - On successful authentication: `(req.session as any).isAdmin = true` (line 130)
   - Express-session middleware automatically:
     - Generates session ID
     - Stores session data in PostgreSQL (via connect-pg-simple)
     - Sets session cookie in HTTP response

4. **Cookie Configuration**
   - **Cookie Name:** `connect.sid` (Express-session default)
   - **Cookie Attributes:**
     - `httpOnly: true` ✅ - Cannot be accessed via JavaScript
     - `secure: false` ⚠️ - Transmitted over HTTP (NOT HTTPS-only)
     - `sameSite: "lax"` ⚠️ - Partial CSRF protection only
     - `maxAge: 7 days` - Session expires after 7 days of inactivity
   - File: `/repos/exo/server/index.ts` (lines 28-45)

5. **Session Validation** (All Protected Routes)
   - Client includes session cookie automatically via `credentials: "include"` (client/lib/queryClient.ts)
   - Express-session middleware loads session from PostgreSQL
   - `requireAdmin` middleware checks `req.session.isAdmin` (server/routes.ts lines 36-41)
   - Returns 401 Unauthorized if not admin

6. **Session Termination** (`POST /api/admin/logout`)
   - Client calls `/api/admin/logout`
   - Server calls `req.session.destroy()` (line 138)
   - Session removed from PostgreSQL database
   - Cookie invalidated

### Code Pointers

**Session Configuration:**
- `/repos/exo/server/index.ts` (lines 28-45) - Express-session setup with PostgreSQL store

**Authentication Endpoints:**
- `/repos/exo/server/routes.ts`:
  - Lines 30-31: Admin credentials from environment variables
  - Lines 36-41: `requireAdmin` middleware
  - Lines 124-135: Admin login handler
  - Lines 137-141: Admin logout handler
  - Lines 143-145: Admin status check

**Client-Side:**
- `/repos/exo/client/src/pages/admin.tsx` (lines 11-65): Login form component
- `/repos/exo/client/src/lib/queryClient.ts` (lines 15-20): API client with credentials

**Database:**
- Session table auto-created by `connect-pg-simple` library
- Schema: `/repos/exo/shared/schema.ts` defines unused `users` table (lines 6-10)

### 3.1 Role Assignment Process

**Role Determination:** Hardcoded - only "admin" role exists, assigned via environment variable authentication.

**Default Role:** Anonymous (unauthenticated) - no user accounts exist.

**Role Upgrade Path:** N/A - No user registration or role elevation mechanism. Only way to become admin is to know the environment variable credentials.

**Code Implementation:**
- Environment variables set admin credentials (server/routes.ts lines 30-31)
- Session flag set on login: `req.session.isAdmin = true` (line 130)
- No database-backed user/role system

### 3.2 Privilege Storage & Validation

**Storage Location:**
- **Primary:** PostgreSQL session table (managed by connect-pg-simple)
- **Data Structure:** Session object contains `{ isAdmin: true }` for authenticated admins
- **Lifetime:** 7 days from last activity

**Validation Points:**
- **Middleware:** `requireAdmin()` function (server/routes.ts lines 36-41)
- **Applied to:** All `/api/admin/*` endpoints (24 total endpoints)
- **Check:** `if (req.session && (req.session as any).isAdmin)`

**Cache/Session Persistence:**
- Session persists for 7 days maximum
- Rolling session: extends on each request
- No absolute timeout beyond 7 days
- Session data loaded from PostgreSQL on every request

**Code Pointers:**
- Session validation: `/repos/exo/server/routes.ts` (lines 36-41)
- Session configuration: `/repos/exo/server/index.ts` (lines 28-45)

### 3.3 Role Switching & Impersonation

**Impersonation Features:** NONE - No impersonation capability exists.

**Role Switching:** NONE - Only logout available, no temporary privilege elevation.

**Audit Trail:** NONE - No logging of admin actions or authentication events.

**Code Implementation:** Not applicable - features do not exist.

**Note:** The only privilege change mechanism is complete session destruction via logout (`POST /api/admin/logout`).


## 4. API Endpoint Inventory

| Method | Endpoint Path | Required Role | Object ID Parameters | Authorization Mechanism | Description & Code Pointer |
|---|---|---|---|---|---|
| POST | /api/admin/login | anon | None | Rate limit only (10/15min) | Admin authentication with plaintext password. `server/routes.ts:124-135` |
| POST | /api/admin/logout | anon | None | None | Session destruction. `server/routes.ts:137-141` |
| GET | /api/admin/check | anon | None | None | ⚠️ Reveals admin status without auth. `server/routes.ts:143-145` |
| GET | /api/products | anon | None | None | Lists visible products only (isHidden=false). `server/routes.ts:75-79` |
| GET | /api/products/:slug | anon | slug | None | ⚠️ Returns ANY product including hidden. `server/routes.ts:81-87` |
| GET | /api/posts | anon | None | None | Lists all posts (lockPassword sanitized). `server/routes.ts:89-93` |
| GET | /api/posts/:slug | anon | slug | None | Returns post (content empty if locked). `server/routes.ts:95-105` |
| POST | /api/posts/:slug/unlock | anon | slug + password | Rate limit (30/15min) | Unlocks password-protected post. `server/routes.ts:107-122` |
| GET | /api/results | anon | None | None | Lists all test results (public). `server/routes.ts:223-226` |
| GET | /api/results/:uid | anon | **uid** | None | 🚨 **IDOR:** Returns ANY result by UID. `server/routes.ts:228-232` |
| GET | /api/pages/:slug | anon | slug | None | Returns site page content. `server/routes.ts:330-336` |
| POST | /api/coupons/validate | anon | None | Rate limit (10/15min) | Validates coupon code. ⚠️ No subtotal validation. `server/routes.ts:447-476` |
| POST | /api/checkout | anon | None | Rate limit (10/15min) | Creates order + BTCPay invoice. `server/routes.ts:478-633` |
| GET | /api/invoice/:invoiceId | anon | **invoiceId** | Rate limit (30/15min) | 🚨 **IDOR + SSRF:** Returns invoice details. `server/routes.ts:635-687` |
| GET | /api/admin/products | admin | None | requireAdmin | Lists ALL products including hidden. `server/routes.ts:147-150` |
| POST | /api/admin/products | admin | None | requireAdmin | Creates product (Zod validated). `server/routes.ts:152-159` |
| PATCH | /api/admin/products/:id | admin | id | requireAdmin | Updates product. `server/routes.ts:161-171` |
| DELETE | /api/admin/products/:id | admin | id | requireAdmin | Deletes product. `server/routes.ts:173-179` |
| GET | /api/admin/posts | admin | None | requireAdmin | Lists ALL posts including passwords. `server/routes.ts:181-184` |
| POST | /api/admin/posts | admin | None | requireAdmin | Creates post (plain text password). `server/routes.ts:186-196` |
| PATCH | /api/admin/posts/:id | admin | id | requireAdmin | Updates post. `server/routes.ts:198-208` |
| DELETE | /api/admin/posts/:id | admin | id | requireAdmin | Deletes post. `server/routes.ts:210-216` |
| GET | /api/admin/results | admin | None | requireAdmin | Lists all test results. `server/routes.ts:234-237` |
| POST | /api/admin/results | admin | None | requireAdmin | 🚨 **Path Traversal:** chromatograms field. `server/routes.ts:239-246` |
| PATCH | /api/admin/results/:id | admin | id | requireAdmin | Updates test result. `server/routes.ts:248-258` |
| DELETE | /api/admin/results/:id | admin | id | requireAdmin | Deletes test result. `server/routes.ts:260-266` |
| POST | /api/admin/upload | admin | None | requireAdmin | ⚠️ Uploads files, no MIME validation. `server/routes.ts:268-279` |
| POST | /api/admin/upload-files | admin | None | requireAdmin | ⚠️ Uploads files with names. `server/routes.ts:281-295` |
| POST | /api/admin/migrate-images | admin | None | requireAdmin | 🚨 **LFI Sink:** Reads files from DB paths. `server/routes.ts:297-328` |
| PUT | /api/admin/pages/:slug | admin | slug | requireAdmin | Creates/updates site page. `server/routes.ts:338-345` |
| GET | /api/admin/orders | admin | None | requireAdmin | Lists all orders with PII. `server/routes.ts:347-350` |
| GET | /api/admin/analytics | admin | None | requireAdmin | Returns business analytics. `server/routes.ts:352-411` |
| GET | /api/admin/coupons | admin | None | requireAdmin | Lists all coupons. `server/routes.ts:413-416` |
| POST | /api/admin/coupons | admin | None | requireAdmin | Creates coupon (Zod validated). `server/routes.ts:418-425` |
| PATCH | /api/admin/coupons/:id | admin | id | requireAdmin | Updates coupon. `server/routes.ts:427-437` |
| DELETE | /api/admin/coupons/:id | admin | id | requireAdmin | Deletes coupon. `server/routes.ts:439-445` |

**Total Endpoints:** 37 (13 public, 24 admin-protected)

**Rate Limiters:**
- **generalLimiter:** 100 requests per 15 minutes (all /api/* routes)
- **strictLimiter:** 10 requests per 15 minutes (login, checkout, coupon validation)
- **moderateLimiter:** 30 requests per 15 minutes (post unlock, invoice view)

## 5. Potential Input Vectors

## 5. Potential Input Vectors for Vulnerability Analysis

### URL Parameters
- `slug` - Product, post, and page identifier
  - Used in: `/api/products/:slug`, `/api/posts/:slug`, `/api/pages/:slug`
  - No validation or sanitization
  - Direct use in database queries (via Drizzle ORM)
  
- `id` - Numeric identifiers for admin operations  
  - Used in: `/api/admin/products/:id`, `/api/admin/posts/:id`, `/api/admin/results/:id`, `/api/admin/coupons/:id`
  - Validation: `parseInt()` + `isNaN()` check
  - File: server/routes.ts (multiple endpoints)

- `uid` - Test result unique identifier
  - Used in: `/api/results/:uid`
  - ⚠️ No validation - potential IDOR
  - File: server/routes.ts:228-232

- `invoiceId` - BTCPay invoice identifier
  - Used in: `/api/invoice/:invoiceId`
  - 🚨 No validation - SSRF vulnerability  
  - File: server/routes.ts:635-687

### POST Body Fields (JSON)

**Admin Login** (`POST /api/admin/login`):
- `username` (string) - No validation, plaintext comparison
- `password` (string) - No validation, plaintext comparison
- File: server/routes.ts:124-135

**Blog Post Unlock** (`POST /api/posts/:slug/unlock`):
- `password` (string) - No validation, plaintext comparison
- File: server/routes.ts:107-122

**Checkout** (`POST /api/checkout`):
- `items` (array of {productId, quantity}) - Server-side validation against product database
- `paymentMethod` (string) - Whitelist: ["btc", "ltc", "xmr"]
- `shippingInfo` (object):
  - `firstName`, `lastName`, `country`, `streetAddress`, `city`, `state`, `zipCode`, `email`
  - Validated with Zod schema (server/routes.ts:539)
  - ⚠️ No sanitization before JSON storage
- `serviceInfo` (object):
  - `clientName`, `expectedCompound`, `manufacturer`, `signalSimplex`
  - Validated with Zod schema (server/routes.ts:547)
  - ⚠️ No sanitization before JSON storage
- `couponCode` (string) - Optional, validated by database lookup
- File: server/routes.ts:478-633

**Coupon Validation** (`POST /api/coupons/validate`):
- `code` (string) - Type checked, lowercase normalized
- `subtotal` (number) - ⚠️ NO TYPE VALIDATION (potential NaN issue)
- File: server/routes.ts:447-476

**Product Management** (`POST /api/admin/products`):
- Full product object validated via Zod `insertProductSchema`
- Fields: name, slug, concentration, type, unitPrice, description, inStock, isHidden, category
- ⚠️ No max length validation on text fields
- File: server/routes.ts:152-159

**Blog Post Management** (`POST /api/admin/posts`):
- Full post object validated via Zod `insertBlogPostSchema`
- Fields: title, slug, content, excerpt, isLocked, lockPassword
- ⚠️ Password stored in plaintext
- ⚠️ No content sanitization (XSS risk if rendered as HTML)
- File: server/routes.ts:186-196

**Test Result Management** (`POST /api/admin/results`):
- Fields: uid, orderUid, testingOrdered, sampleReceived, clientName, sample, manufacturer, results, chromatograms, rawDataFiles
- 🚨 **chromatograms** field: JSON array of file paths - PATH TRAVERSAL VULNERABILITY
- 🚨 **rawDataFiles** field: JSON array - similar risk
- File: server/routes.ts:239-246

**Coupon Management** (`POST /api/admin/coupons`):
- Fields: code, discountType, discountValue, minOrderAmount, maxUses, isActive
- Code normalized to lowercase
- Validated via Zod `insertCouponSchema`
- File: server/routes.ts:418-425

**File Upload** (`POST /api/admin/upload`, `POST /api/admin/upload-files`):
- Multipart form data, up to 10 files
- ⚠️ NO MIME TYPE VALIDATION
- ⚠️ Trusts client-provided mimetype
- Max size: 10MB per file
- File: server/routes.ts:268-295

### HTTP Headers
- `Cookie: connect.sid=<session_id>` - Session authentication
- Standard headers accepted by Express (no custom header processing identified)

### Cookie Values
- `connect.sid` - Express session cookie
  - Duration: 7 days
  - httpOnly: true
  - secure: false ⚠️
  - sameSite: lax ⚠️
  - File: server/index.ts:28-45

### Form Data (Multipart)
- File uploads via multer
- Files stored in memory (not disk)
- Converted to base64 data URIs
- Files: server/routes.ts:268-295

## 6. Network & Interaction Map

### 6.1 Entities

| Title | Type | Zone | Tech | Data | Notes |
|---|---|---|---|---|---|
| ExogenousApp | Service | App | Express/TypeScript | PII, Tokens, Payments | Main application server on port 5000 |
| PostgreSQL-DB | DataStore | Data | PostgreSQL | PII, Tokens, Secrets | Stores all application data + sessions |
| BTCPayServer | ThirdParty | External | BTCPay | Payments | Cryptocurrency payment processor |
| Cloudflare | ThirdParty | Edge | Cloudflare CDN | Public | CDN and security layer |
| UserBrowser | ExternAsset | Internet | React/Browser | Public | Client-side React application |

### 6.2 Entity Metadata

| Title | Metadata |
|---|---|
| ExogenousApp | Hosts: `https://exogenous.fun`; Endpoints: `/api/*`, `/admin`, `/products`, `/results`, `/checkout/:id`; Auth: Session Cookie (7-day); Dependencies: PostgreSQL-DB, BTCPayServer; Rate Limits: 10-100 req/15min |
| PostgreSQL-DB | Engine: PostgreSQL; Exposure: Internal Only; Consumers: ExogenousApp; Tables: users (unused), products, blogPosts, orders, testResults, coupons, sitePages, session; Credentials: DATABASE_URL env var |
| BTCPayServer | API URL: BTCPAY_URL env var; Auth: BTCPAY_API_KEY; Store: BTCPAY_STORE_ID; Methods: BTC, LTC, XMR; Invoice Format: JSON; Webhooks: Not implemented |
| Cloudflare | Services: CDN, WAF, DDoS protection; Endpoints: `/cdn-cgi/rum` (analytics); SSL: Flexible/Full |
| UserBrowser | Runtime: Modern browsers; Framework: React 18; Storage: Session cookies; API Client: TanStack Query with credentials:include |

### 6.3 Flows (Connections)

| FROM → TO | Channel | Path/Port | Guards | Touches |
|---|---|---|---|---|
| UserBrowser → Cloudflare | HTTPS | :443 /* | None | Public, PII (forms) |
| Cloudflare → ExogenousApp | HTTP/HTTPS | :5000 /api/* | Rate limits | Public, PII, Tokens |
| UserBrowser → ExogenousApp | HTTPS | :443 /admin | None (client-side check) | Public |
| ExogenousApp → PostgreSQL-DB | TCP | :5432 | vpc-only | PII, Tokens, Secrets |
| ExogenousApp → BTCPayServer | HTTPS | /api/v1/* | api-key | Payments |
| UserBrowser → ExogenousApp | HTTPS | :443 /api/admin/* | auth:admin, rate:100/15min | PII, Secrets |
| UserBrowser → ExogenousApp | HTTPS | :443 /api/checkout | rate:10/15min | PII, Payments |
| UserBrowser → ExogenousApp | HTTPS | :443 /api/posts/:slug/unlock | rate:30/15min | Public |
| ExogenousApp → UserBrowser | HTTPS | :443 /api/results/:uid | None (IDOR) | PII |
| ExogenousApp → UserBrowser | HTTPS | :443 /api/invoice/:invoiceId | rate:30/15min (IDOR) | Payments |

### 6.4 Guards Directory

| Guard Name | Category | Statement |
|---|---|---|
| auth:admin | Auth | Requires valid admin session with `req.session.isAdmin === true`. Enforced by `requireAdmin` middleware. |
| rate:10/15min | RateLimit | Strict rate limit: 10 requests per 15 minutes. Applied to sensitive endpoints (login, checkout, coupon validation). |
| rate:30/15min | RateLimit | Moderate rate limit: 30 requests per 15 minutes. Applied to post unlock and invoice viewing. |
| rate:100/15min | RateLimit | General rate limit: 100 requests per 15 minutes. Applied to all /api/* routes. |
| vpc-only | Network | Database accessible only within internal network. Not exposed to internet. |
| api-key | Protocol | BTCPay Server API requires BTCPAY_API_KEY header for authentication. |
| ownership:none | ObjectOwnership | ⚠️ NO OWNERSHIP VALIDATION - Any user can access any resource if they know the identifier (uid, invoiceId). |
| session:7day | Auth | Session cookies expire after 7 days of inactivity. Rolling expiration on each request. |
| httponly | Protocol | Session cookie has httpOnly flag preventing JavaScript access. |
| insecure:cookie | Protocol | ⚠️ Session cookie has `secure: false`, allowing transmission over HTTP. |

## 7. Role & Privilege Architecture

### 7.1 Discovered Roles

| Role Name | Privilege Level | Scope/Domain | Code Implementation |
|---|---|---|---|
| anon | 0 | Global | No authentication - default state for all visitors |
| admin | 10 | Global | Session flag `req.session.isAdmin === true` set after environment credential authentication |

**Note:** Only TWO roles exist. No user accounts, no registration, no intermediate privilege levels.

### 7.2 Privilege Lattice

```
Privilege Ordering (→ means "can access resources of"):
anon → anon only (public endpoints)
admin → admin + anon (all endpoints)

No Parallel Isolation - Simple binary privilege model.
No role inheritance or delegation.
```

**Role Switching:** None available. Only logout (complete session destruction).

### 7.3 Role Entry Points

| Role | Default Landing Page | Accessible Route Patterns | Authentication Method |
|---|---|---|---|
| anon | `/` (musings/home) | `/`, `/products`, `/results`, `/terms`, `/checkout/*`, `/product/*`, `/results/*` | None |
| admin | `/admin` (after login redirects to admin panel) | All routes + `/admin`, `/api/admin/*` | Session cookie after env credential auth |

### 7.4 Role-to-Code Mapping

| Role | Middleware/Guards | Permission Checks | Storage Location |
|---|---|---|---|
| anon | None (default) | N/A | N/A |
| admin | `requireAdmin` (server/routes.ts:36-41) | `req.session && req.session.isAdmin` | PostgreSQL session table (connect-pg-simple) |

## 8. Authorization Vulnerability Candidates

### 8.1 Horizontal Privilege Escalation Candidates (IDOR)

| Priority | Endpoint Pattern | Object ID Parameter | Data Type | Sensitivity | Notes |
|---|---|---|---|---|---|
| HIGH | `/api/results/:uid` | uid | test_results | High (PII: clientName, sample, manufacturer) | 🚨 No ownership validation. Anyone can view any result. |
| HIGH | `/api/invoice/:invoiceId` | invoiceId | payment_invoice | High (payment details, amounts, addresses) | 🚨 No session validation. Anyone can view any invoice. |
| MEDIUM | `/api/products/:slug` | slug | product | Low (but bypasses isHidden filter) | Returns hidden products that should be admin-only. |
| MEDIUM | `/api/posts/:slug` | slug | blog_post | Low-Medium (content, but password-protected if locked) | Password protection exists but brute-forceable (30 attempts/15min). |
| LOW | `/api/pages/:slug` | slug | site_page | Low (public content) | By design returns empty if not found. |

### 8.2 Vertical Privilege Escalation Candidates

**All admin endpoints require `requireAdmin` middleware - properly protected at code level.**

However, the following weaknesses exist:

| Target Role | Endpoint Pattern | Functionality | Risk Level | Notes |
|---|---|---|---|---|
| admin | `/api/admin/check` | Admin status check | MEDIUM | ⚠️ Reveals if current session is admin without authentication. Enables session enumeration. |
| admin | `/api/admin/login` | Admin authentication | HIGH | 🚨 Plaintext password in environment. Credentials exposed in .replit file. Rate limited to 10/15min. |
| admin | All `/api/admin/*` | Admin operations | LOW | ✅ Properly protected by requireAdmin middleware. Session-based auth with 7-day expiration. |

**No user role escalation candidates** - Application has no user accounts or role upgrade mechanisms.

### 8.3 Context-Based Authorization Candidates

| Workflow | Endpoint | Expected Prior State | Bypass Potential | Notes |
|---|---|---|---|---|
| Payment | `/api/invoice/:invoiceId` | Order created via /checkout | MEDIUM | Can view ANY invoice without creating order. Invoices not linked to sessions. |
| Checkout | `/api/checkout` | Items in cart | LOW | Server validates products exist and calculates total server-side. |
| Post Unlock | `/api/posts/:slug/unlock` | Post is locked | LOW | Validates lock status server-side. But password is plaintext comparison. |
| Result View | `/api/results/:uid` | Testing order placed | HIGH | 🚨 No validation that user placed the order. Results publicly accessible by UID. |

**No multi-step workflows with state dependencies** - Most operations are single-request transactions.

## 9. Injection Sources (Command Injection, SQL Injection, LFI/RFI, SSTI, Path Traversal, Deserialization)

### 🚨 CRITICAL INJECTION VULNERABILITIES IDENTIFIED

### VULNERABILITY #1: Path Traversal / Local File Inclusion (LFI)

**Injection Type:** Path Traversal / Local File Inclusion

**Severity:** HIGH (Admin-authenticated, but allows arbitrary file read)

**Complete Data Flow:**

1. **Network Entry Point:**
   - Endpoint: `POST /api/admin/results`
   - File: `/repos/exo/server/routes.ts:239-246`
   - Authentication: requireAdmin (session-based)
   
2. **User Input (Source):**
   - Field: `chromatograms` (JSON string array)
   - Example payload: `{ "chromatograms": "['/uploads/../../../etc/passwd']" }`
   - Validation: Zod schema accepts any string
   
3. **Data Storage:**
   - Stored in PostgreSQL `test_results.chromatograms` column as JSON text
   - No path validation or sanitization performed
   
4. **Dangerous Sink:**
   - Endpoint: `POST /api/admin/migrate-images`
   - File: `/repos/exo/server/routes.ts:297-328`
   - Line 302: `const chromatograms: string[] = JSON.parse(result.chromatograms || "[]");`
   - Line 306: `const filePath = path.join(process.cwd(), url);` ← Vulnerable line
   - Line 308: `const fileBuffer = fs.readFileSync(filePath);` ← Dangerous sink (file read)
   - Line 309: Returns file contents as base64

**Attack Scenario:**
```javascript
// Step 1: Admin creates malicious test result
POST /api/admin/results
{
  "uid": "attack123",
  "chromatograms": "['/uploads/../../../etc/passwd', '/uploads/../../server/.env']"
}

// Step 2: Trigger migration
POST /api/admin/migrate-images

// Result: Application reads /etc/passwd and returns as base64
```

**Why It Works:**
- `path.join(process.cwd(), '/uploads/../../../etc/passwd')` normalizes to `/etc/passwd`
- Only check is `if (url.startsWith("/uploads/"))` which is bypassed with `../`
- `fs.readFileSync()` executes with normalized path
- File contents returned as base64 in API response

### VULNERABILITY #2: Server-Side Request Forgery (SSRF)

**Injection Type:** Server-Side Request Forgery (SSRF)

**Severity:** MEDIUM (Limited by URL construction, but can probe internal BTCPay endpoints)

**Complete Data Flow:**

1. **Network Entry Point:**
   - Endpoint: `GET /api/invoice/:invoiceId`
   - File: `/repos/exo/server/routes.ts:635-687`
   - Authentication: None (public endpoint)
   - Rate Limit: 30 requests per 15 minutes
   
2. **User Input (Source):**
   - Parameter: `invoiceId` (URL path parameter)
   - No validation or sanitization
   - Example: `GET /api/invoice/../../admin/users`
   
3. **Dangerous Sink:**
   - Lines 650-651: User input concatenated into fetch URLs
   ```typescript
   fetchWithRetry(`${BTCPAY_URL}/api/v1/stores/${BTCPAY_STORE_ID}/invoices/${req.params.invoiceId}`)
   fetchWithRetry(`${BTCPAY_URL}/api/v1/stores/${BTCPAY_STORE_ID}/invoices/${req.params.invoiceId}/payment-methods`)
   ```
   - Server makes HTTP request to constructed URL
   - Response returned to attacker (lines 667-682)

**Attack Scenario:**
```
GET /api/invoice/../../admin/users

Resulting URL:
${BTCPAY_URL}/api/v1/stores/${BTCPAY_STORE_ID}/invoices/../../admin/users

Could access unintended BTCPay Server endpoints
```

### ✅ NO VULNERABILITIES FOUND FOR:

**SQL Injection:** ✅ PROTECTED
- Uses Drizzle ORM with parameterized queries
- All queries use `eq()`, `select()`, `insert()`, etc. with proper binding
- No raw SQL with user input (only static DDL for table creation)

**Command Injection:** ✅ PROTECTED
- No use of `exec`, `spawn`, `execSync`, `execFile`, `child_process` with user input
- No shell command execution found

**Server-Side Template Injection (SSTI):** ✅ PROTECTED
- Template usage only for static HTML replacement with `nanoid()` (server/vite.ts:46-47)
- No user input embedded in templates

**Insecure Deserialization:** ✅ PROTECTED
- `JSON.parse()` used only on trusted database data
- No parsing of user-controlled JSON beyond Express middleware
- All deserialization is of application-generated data

**Cross-Site Scripting (XSS):** ⚠️ CLIENT-SIDE ONLY
- No server-side HTML rendering with user input
- Client uses React which auto-escapes by default
- One use of `dangerouslySetInnerHTML` in chart component (client/components/ui/chart.tsx:81) but only for theme config

### Summary of Injection Vulnerabilities

**Total Network-Accessible Injection Vulnerabilities:** 2

1. **Path Traversal/LFI** (HIGH) - Admin can read arbitrary files via chromatograms field
2. **SSRF** (MEDIUM) - Unauthenticated users can probe BTCPay Server endpoints

**Recommended Mitigations:**
1. LFI: Validate file paths with `path.resolve()` and check resolved path starts with allowed directory
2. SSRF: Validate `invoiceId` matches expected format (UUID/alphanumeric only) before URL construction

