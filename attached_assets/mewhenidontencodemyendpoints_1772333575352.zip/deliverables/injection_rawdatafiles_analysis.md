# Path Traversal Analysis: rawDataFiles Field

## Executive Summary

**Vulnerability:** Path Traversal via rawDataFiles field
**Verdict:** NOT VULNERABLE
**Confidence:** HIGH (95%)
**Externally Exploitable:** N/A (no vulnerability found)

The `rawDataFiles` field does NOT have a path traversal vulnerability, despite being similar in structure to the vulnerable `chromatograms` field. The key difference is that `rawDataFiles` is never used in file system operations - it only stores base64-encoded data URIs that are rendered client-side for download links.

---

## 1. Source Analysis

### Field Definition
**Location:** `/repos/exo/shared/schema.ts:97`
```typescript
export const testResults = pgTable("test_results", {
  id: serial("id").primaryKey(),
  uid: text("uid").notNull().unique(),
  orderUid: text("order_uid"),
  testingOrdered: text("testing_ordered"),
  sampleReceived: text("sample_received"),
  clientName: text("client_name"),
  sample: text("sample"),
  manufacturer: text("manufacturer"),
  results: text("results"),
  chromatograms: text("chromatograms").notNull().default("[]"),
  rawDataFiles: text("raw_data_files").notNull().default("[]"),  // <-- HERE
  createdAt: timestamp("created_at").defaultNow(),
});
```

**Type:** PostgreSQL TEXT column storing JSON array of objects
**Format:** `[{"name": "filename.txt", "data": "data:application/octet-stream;base64,..."}, ...]`
**Default:** `"[]"` (empty JSON array)

### Data Input Points

#### Primary Input: POST /api/admin/results
**Location:** `/repos/exo/server/routes.ts:239-246`
```typescript
app.post("/api/admin/results", requireAdmin, async (req, res) => {
  const parsed = insertTestResultSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ message: "Invalid result data", errors: parsed.error.flatten() });
  }
  const result = await storage.createTestResult(parsed.data);
  res.status(201).json(result);
});
```

**Access Control:** Requires admin authentication (`requireAdmin` middleware)
**Validation:** Zod schema validation via `insertTestResultSchema`
**Schema:** Derived from database schema (no additional constraints on rawDataFiles)

#### Secondary Input: PATCH /api/admin/results/:id
**Location:** `/repos/exo/server/routes.ts:248-258`
```typescript
app.patch("/api/admin/results/:id", requireAdmin, async (req, res) => {
  const id = parseInt(String(req.params.id));
  if (isNaN(id)) return res.status(400).json({ message: "Invalid ID" });
  const parsed = insertTestResultSchema.partial().safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ message: "Invalid result data", errors: parsed.error.flatten() });
  }
  const result = await storage.updateTestResult(id, parsed.data);
  if (!result) return res.status(404).json({ message: "Result not found" });
  res.json(result);
});
```

**Access Control:** Requires admin authentication
**Validation:** Partial Zod schema validation

---

## 2. Data Flow Analysis

### Complete Data Flow

```
┌─────────────────────────────────────────────────────────────────┐
│ SOURCE: Admin uploads files                                      │
│ POST /api/admin/upload-files (server/routes.ts:281-295)        │
│ - Accepts multipart/form-data files                            │
│ - Returns: {files: [{name: string, data: dataURI}]}            │
│ - No validation on file names or content                       │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ CLIENT: Admin form prepares data                                 │
│ client/src/pages/admin.tsx:646-674                              │
│ - State: rawFiles: {name: string, data: string}[]              │
│ - Serialization: JSON.stringify(rawFiles)                      │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ STORAGE: Database insertion                                      │
│ POST /api/admin/results (server/routes.ts:239-246)             │
│ - Validates with insertTestResultSchema                        │
│ - Stores: test_results.raw_data_files (PostgreSQL TEXT)        │
│ - Format: '[{"name":"...", "data":"data:...;base64,..."}]'     │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ RETRIEVAL: Public/Admin endpoints                               │
│ GET /api/results (server/routes.ts:223-226) - PUBLIC           │
│ GET /api/results/:uid (server/routes.ts:228-232) - PUBLIC      │
│ GET /api/admin/results (server/routes.ts:234-237) - ADMIN      │
│ - Returns complete TestResult including rawDataFiles           │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ CLIENT RENDERING: Download links                                │
│ client/src/pages/result-detail.tsx:40, 103-114                 │
│ - Parses: JSON.parse(result.rawDataFiles || "[]")              │
│ - Renders: <a href={file.data} download={file.name}>           │
│ - No server-side file operations                               │
└─────────────────────────────────────────────────────────────────┘
```

### Key Observations

1. **No File System Operations:** Unlike `chromatograms`, the `rawDataFiles` field is NEVER used in any `fs.*` operations
2. **Client-Side Only:** Data is rendered client-side as download links using data URIs
3. **Base64 Encoded:** All files are stored as base64-encoded data URIs, not file paths
4. **Public Access:** Data is returned to non-admin users via `/api/results` endpoints

---

## 3. Sink Analysis

### File System Operations Search

**Search Pattern:** All `fs.*` operations in server code
```bash
grep -rn "fs\.(readFileSync|existsSync|writeFileSync|readFile|writeFile|unlink|stat)" server/
```

**Results:**
```
server/routes.ts:219:  if (fs.existsSync(uploadDir)) {
server/routes.ts:307:            if (fs.existsSync(filePath)) {
server/routes.ts:308:              const fileBuffer = fs.readFileSync(filePath);
server/static.ts:7:  if (!fs.existsSync(distPath)) {
```

### Detailed Analysis of Each fs.* Call

#### 1. server/routes.ts:219 - Upload directory check
```typescript
if (fs.existsSync(uploadDir)) {
  // cleanup code
}
```
**Context:** Unrelated to rawDataFiles

#### 2. server/routes.ts:307-308 - Chromatograms migration (VULNERABLE)
```typescript
const chromatograms: string[] = JSON.parse(result.chromatograms || "[]");
let changed = false;
const updated = chromatograms.map((url) => {
  if (url.startsWith("/uploads/")) {
    const filePath = path.join(process.cwd(), url);  // <-- PATH TRAVERSAL
    if (fs.existsSync(filePath)) {
      const fileBuffer = fs.readFileSync(filePath);  // <-- VULNERABLE SINK
      // ... convert to base64 ...
    }
  }
  return url;
});
```
**Context:** This is the VULNERABLE chromatograms path traversal
**rawDataFiles involvement:** NONE - rawDataFiles is NOT processed here

#### 3. server/static.ts:7 - Static file serving
```typescript
if (!fs.existsSync(distPath)) {
  // ... error handling ...
}
```
**Context:** Unrelated to rawDataFiles

### Migration Endpoint Analysis

**Location:** `/repos/exo/server/routes.ts:297-328`
```typescript
app.post("/api/admin/migrate-images", requireAdmin, async (_req, res) => {
  try {
    const results = await storage.getTestResults();
    let migrated = 0;
    for (const result of results) {
      const chromatograms: string[] = JSON.parse(result.chromatograms || "[]");
      // ^^^^^ ONLY chromatograms is processed, NOT rawDataFiles
      let changed = false;
      const updated = chromatograms.map((url) => {
        if (url.startsWith("/uploads/")) {
          const filePath = path.join(process.cwd(), url);
          if (fs.existsSync(filePath)) {
            const fileBuffer = fs.readFileSync(filePath);
            // ... base64 conversion ...
          }
        }
        return url;
      });
      if (changed) {
        await storage.updateTestResult(result.id, { chromatograms: JSON.stringify(updated) });
        migrated++;
      }
    }
    res.json({ success: true, migrated });
  } catch (error) {
    console.error("Migration error:", error);
    res.status(500).json({ message: "Migration failed" });
  }
});
```

**Key Finding:** The migrate-images endpoint ONLY processes the `chromatograms` field, NOT `rawDataFiles`

---

## 4. Comparison with chromatograms Field

### Similarities

| Aspect | chromatograms | rawDataFiles |
|--------|--------------|--------------|
| Database type | TEXT (JSON array) | TEXT (JSON array) |
| Input endpoint | POST /api/admin/results | POST /api/admin/results |
| Access control | Admin-only | Admin-only |
| Schema validation | insertTestResultSchema | insertTestResultSchema |
| Public retrieval | Yes (GET /api/results) | Yes (GET /api/results) |

### Critical Differences

| Aspect | chromatograms | rawDataFiles | Impact |
|--------|--------------|--------------|--------|
| **Storage format** | Array of strings (URLs) | Array of objects {name, data} | rawDataFiles stores data URIs, not paths |
| **File operations** | **YES - fs.readFileSync in migrate-images** | **NO - never used in fs.* calls** | chromatograms has path traversal, rawDataFiles does not |
| **Migration processing** | Processed in POST /api/admin/migrate-images | NOT processed | No opportunity for path traversal |
| **Client usage** | Image src attribute | Download link href attribute | Both client-side, but different rendering |

### Why chromatograms is Vulnerable but rawDataFiles is Not

**chromatograms vulnerability chain:**
1. Admin stores path: `"/uploads/../../../etc/passwd"`
2. migrate-images endpoint reads: `JSON.parse(result.chromatograms)`
3. Path concatenation: `path.join(process.cwd(), "/uploads/../../../etc/passwd")`
4. File read: `fs.readFileSync(filePath)` → **PATH TRAVERSAL**

**rawDataFiles safe chain:**
1. Admin stores object: `{"name": "test.txt", "data": "data:text/plain;base64,..."}`
2. No migration endpoint processes rawDataFiles
3. No file system operations use rawDataFiles
4. Client renders: `<a href={file.data} download={file.name}>` → **SAFE**

---

## 5. Code References

### Schema Definition
- **File:** `/repos/exo/shared/schema.ts`
- **Line:** 97
- **Code:** `rawDataFiles: text("raw_data_files").notNull().default("[]")`

### Server-Side Input
- **File:** `/repos/exo/server/routes.ts`
- **Lines:** 239-246 (POST), 248-258 (PATCH)
- **Code:** Input validation and database insertion

### Server-Side Output
- **File:** `/repos/exo/server/routes.ts`
- **Lines:** 223-226 (GET /api/results), 228-232 (GET /api/results/:uid)
- **Code:** Returns complete TestResult objects

### Client-Side Usage
- **File:** `/repos/exo/client/src/pages/result-detail.tsx`
- **Line:** 40 (parsing), 103-114 (rendering)
- **Code:**
```typescript
const rawDataFiles: { name: string; data: string }[] = JSON.parse(result.rawDataFiles || "[]");
// ...
{rawDataFiles.map((file, i) => (
  <a href={file.data} download={file.name}>
    {/* download link */}
  </a>
))}
```

### Admin Form
- **File:** `/repos/exo/client/src/pages/admin.tsx`
- **Line:** 646 (parsing), 674 (submission)
- **Code:**
```typescript
const existingRawFiles: { name: string; data: string }[] =
  result ? JSON.parse(result.rawDataFiles || "[]") : [];
// ...
rawDataFiles: JSON.stringify(rawFiles)
```

---

## 6. Vulnerability Assessment

### Potential Attack Vector (Hypothetical)

If rawDataFiles were processed similarly to chromatograms, the attack would be:

```json
POST /api/admin/results
{
  "uid": "TEST-001",
  "rawDataFiles": "[{\"name\": \"test.txt\", \"data\": \"/uploads/../../../etc/passwd\"}]"
}
```

Then if a migration endpoint existed:
```typescript
// HYPOTHETICAL (DOES NOT EXIST)
const rawFiles = JSON.parse(result.rawDataFiles || "[]");
rawFiles.forEach(file => {
  if (file.data.startsWith("/uploads/")) {
    const filePath = path.join(process.cwd(), file.data);
    fs.readFileSync(filePath); // <-- WOULD BE VULNERABLE
  }
});
```

### Why This Attack Fails

1. **No migration endpoint for rawDataFiles:** The POST /api/admin/migrate-images endpoint only processes chromatograms
2. **No file system operations:** Zero `fs.*` calls reference rawDataFiles
3. **Data URI format:** The expected format is `data:*/*;base64,...`, not file paths
4. **Client-side rendering:** All usage is browser-side download links

### Grep Verification

```bash
# Search for rawDataFiles usage in server code
grep -rn "rawDataFiles\|rawFiles\|raw_data_files" server/
# Result: NO MATCHES (only in deliverable docs)

# Search for all fs.* operations
grep -rn "fs\." server/routes.ts
# Result: Lines 219, 307, 308 - NONE related to rawDataFiles
```

---

## 7. Verdict

### NOT VULNERABLE

**Confidence Level:** HIGH (95%)

**Reasoning:**
1. **No sink exists:** rawDataFiles is never used in any file system operations
2. **No path processing:** The migrate-images endpoint only processes chromatograms
3. **Format mismatch:** rawDataFiles stores {name, data} objects, not file paths
4. **Client-side only:** All usage is browser-side rendering of data URIs
5. **Comprehensive search:** Grep confirms zero server-side file operations using rawDataFiles

### Why Not 100% Confidence?

The 5% uncertainty accounts for:
- Potential future code changes that could introduce file operations
- Possibility of indirect usage through complex object serialization
- Edge cases in third-party libraries processing the data

However, based on current codebase analysis, there is **no exploitable path traversal vulnerability** in the rawDataFiles field.

---

## 8. Comparison Summary

| Field | Vulnerable? | Sink | Exploitable? |
|-------|------------|------|--------------|
| **chromatograms** | ✅ YES | POST /api/admin/migrate-images (fs.readFileSync at line 308) | ⚠️ Admin-only (externally_exploitable = false) |
| **rawDataFiles** | ❌ NO | No file operations found | ❌ N/A |

---

## 9. Recommendations

While rawDataFiles is not vulnerable to path traversal, consider these security improvements:

1. **Validation Enhancement:**
   - Add Zod schema validation to ensure rawDataFiles only contains objects with `name` and `data` properties
   - Validate that `data` field matches data URI format: `^data:[^;]+;base64,`
   - Sanitize `name` field to prevent XSS via download attribute

2. **Future-Proofing:**
   - Document that rawDataFiles should NEVER be used in file system operations
   - Add code comments warning against using rawDataFiles as file paths
   - If migration functionality is needed, ensure it validates data URI format first

3. **Consistent Naming:**
   - Current format suggests files, but they're actually base64 data URIs
   - Consider renaming to `embeddedFiles` or `dataUriFiles` to clarify purpose

---

## 10. References

### Files Analyzed
- `/repos/exo/shared/schema.ts` - Schema definition
- `/repos/exo/server/routes.ts` - API endpoints and file operations
- `/repos/exo/server/storage.ts` - Database operations
- `/repos/exo/client/src/pages/result-detail.tsx` - Client rendering
- `/repos/exo/client/src/pages/admin.tsx` - Admin form handling

### Related Vulnerabilities
- **INJECTION-002:** Path Traversal via chromatograms field (CONFIRMED VULNERABLE)
- This analysis confirms rawDataFiles does NOT share the same vulnerability

---

**Analysis Date:** 2026-03-01
**Analyst:** Security Review
**Phase:** INJECTION ANALYSIS
