# SSRF Analysis Report

## 1. Executive Summary

- **Analysis Status:** Complete
- **Key Outcome:** One medium-confidence SSRF vulnerability was identified in the invoice retrieval endpoint. While the vulnerability exists at the code level with completely missing input validation, practical exploitation is limited by Express.js URL normalization and the constraint that requests are made to a pre-configured external BTCPay server.
- **Purpose of this Document:** This report provides the strategic context on the application's outbound request mechanisms, dominant flaw patterns, and key architectural details necessary to understand the SSRF attack surface of the exogenous.fun application.

## 2. Application Architecture Overview

### Technology Stack
- **Backend Framework:** Express.js 5.0.1 (Node.js)
- **Language:** TypeScript 5.6.3
- **HTTP Client:** Native Node.js `fetch()` API
- **Database:** PostgreSQL with Drizzle ORM
- **External Integration:** BTCPay Server for cryptocurrency payment processing

### HTTP Client Usage
The application makes outbound HTTP requests exclusively through a custom `fetchWithRetry()` wrapper function that provides retry logic but **no security controls**. All outbound requests target the BTCPay Server configured via environment variables.

**HTTP Client Implementation (routes.ts:18-28):**
```typescript
async function fetchWithRetry(url: string, options: RequestInit, retries = 3): Promise<Response> {
  for (let i = 0; i < retries; i++) {
    try {
      return await fetch(url, options);
    } catch (err) {
      if (i === retries - 1) throw err;
      await new Promise((r) => setTimeout(r, 500 * (i + 1)));
    }
  }
  throw new Error("fetch failed after retries");
}
```

**Security Analysis:**
- ❌ No URL validation
- ❌ No protocol restriction (could accept file://, gopher://, etc. if passed)
- ❌ No IP range blocklist (no protection against 127.0.0.1, 169.254.x.x, 10.x.x.x)
- ❌ No hostname validation
- ⚠️ Simply wraps native `fetch()` with retry mechanism

## 3. Dominant Vulnerability Patterns

### Pattern 1: Missing Input Validation on URL Path Parameters

**Description:** A critical pattern was observed where user-supplied URL path parameters are directly interpolated into outbound HTTP request URLs without any validation, sanitization, or encoding. The `invoiceId` route parameter in the GET /api/invoice/:invoiceId endpoint is used directly in URL construction without checking for malicious characters, path traversal sequences, or URL injection attempts.

**Implication:** Attackers could potentially manipulate the URL path to access unintended BTCPay Server endpoints or attempt path traversal attacks. However, practical exploitation is limited by:
1. Express.js normalizes URLs before routing (../../ sequences are resolved at the HTTP layer)
2. The base URL (BTCPAY_URL) is server-controlled via environment variables
3. Requests must go to the pre-configured BTCPay Server instance

**Representative Finding:** `SSRF-VULN-01` - GET /api/invoice/:invoiceId

**Code Evidence:**
```typescript
// Line 635-651 in routes.ts
app.get("/api/invoice/:invoiceId", moderateLimiter, async (req, res) => {
  // ... no validation of req.params.invoiceId ...

  const [invoiceRes, methodsRes] = await Promise.all([
    fetchWithRetry(
      `${BTCPAY_URL}/api/v1/stores/${BTCPAY_STORE_ID}/invoices/${req.params.invoiceId}`,
      { headers }
    ),
    fetchWithRetry(
      `${BTCPAY_URL}/api/v1/stores/${BTCPAY_STORE_ID}/invoices/${req.params.invoiceId}/payment-methods`,
      { headers }
    ),
  ]);
```

**Severity:** Medium - Code-level vulnerability exists but practical exploitation is constrained

### Pattern 2: Lack of URL Allowlisting and Protocol Restrictions

**Description:** The application does not implement URL allowlisting, protocol restrictions, or network-level controls in the HTTP client wrapper. While the current codebase only makes requests to BTCPay Server endpoints (controlled by environment variables), the `fetchWithRetry()` function would accept any URL if called with attacker-controlled input.

**Implication:** If future code changes introduce new endpoints that use `fetchWithRetry()` with user-controlled URLs, SSRF vulnerabilities could be introduced without any defensive layers in place. The lack of defense-in-depth means the application relies entirely on developers remembering to validate inputs at each call site.

**Recommended Defense:** Implement URL validation in the `fetchWithRetry()` wrapper to enforce:
- Protocol allowlist (https:// only, or http:// for localhost in development)
- Domain allowlist (only expected external services)
- IP range blocklist (RFC 1918 private ranges, link-local, localhost)

## 4. Strategic Intelligence for Exploitation

### HTTP Client Architecture

**Primary HTTP Client:** Native Node.js `fetch()` API (available in Node.js 18+)
- **Wrapper Function:** `fetchWithRetry()` provides exponential backoff retry logic
- **Usage Pattern:** All outbound requests use this wrapper
- **Security Posture:** Zero security controls at the HTTP client layer

**Request Destinations:**
1. **BTCPay Server API** - Configured via environment variables
   - Base URL: `process.env.BTCPAY_URL`
   - Store ID: `process.env.BTCPAY_STORE_ID`
   - Authentication: `Authorization: token ${BTCPAY_API_KEY}` header
   - Endpoints accessed:
     - `POST /api/v1/stores/{storeId}/invoices` (invoice creation)
     - `GET /api/v1/stores/{storeId}/invoices/{invoiceId}` (invoice retrieval)
     - `GET /api/v1/stores/{storeId}/invoices/{invoiceId}/payment-methods` (payment methods)

### Identified SSRF Surface

**Total Outbound Request Endpoints:** 2
1. **POST /api/checkout** - ✅ SAFE (environment-controlled destination, no user input in URL)
2. **GET /api/invoice/:invoiceId** - ⚠️ VULNERABLE (user input in URL path, no validation)

**Admin Endpoints Analysis:**
- **Authentication Status:** Admin login is enabled on the live system
- **Tested Credentials:** The exposed password from `.replit` file was tested with common usernames (admin, administrator, root, supplements, exogenous, test) - all failed
- **File-Based SSRF:** POST /api/admin/migrate-images contains a critical file-based SSRF vulnerability allowing arbitrary file reads via path traversal, but requires admin authentication
- **External Exploitability:** Admin endpoints are NOT externally exploitable without valid credentials

### Network-Level Observations

**Rate Limiting:**
- **Strict Limiter:** 10 requests per 15 minutes (checkout, admin login)
- **Moderate Limiter:** 30 requests per 15 minutes (invoice retrieval)
- **Implementation:** Uses `express-rate-limit` middleware

**Infrastructure:**
- **CDN:** Cloudflare (observed in response headers)
- **Hosting:** Likely Replit-based (inferred from codebase structure)
- **TLS:** HTTPS enforced via Strict-Transport-Security header

### BTCPay Server Integration

**Configuration:**
- **URL:** Set via `BTCPAY_URL` environment variable (not visible in source code)
- **Authentication:** API key in `BTCPAY_API_KEY` environment variable
- **Store Identifier:** `BTCPAY_STORE_ID` environment variable
- **Optional Proxy Key:** `BTCPAY_PROXY_KEY` for additional authentication

**Request Headers Added:**
```typescript
{
  "Authorization": `token ${BTCPAY_API_KEY}`,
  "User-Agent": "SupplementsShop/1.0",
  "X-Api-Key": BTCPAY_PROXY_KEY  // conditional
}
```

**Security Implication:** All requests to BTCPay Server are authenticated with the application's API key, which means successful SSRF could leverage these credentials to access sensitive payment data or administrative functions on the BTCPay Server.

## 5. Detailed Vulnerability Analysis

### SSRF-VULN-01: Unauthenticated SSRF via Invoice ID Parameter

**Endpoint:** `GET /api/invoice/:invoiceId`
**File Location:** `/repos/exo/server/routes.ts:635-687`
**Vulnerability Type:** URL Manipulation / Missing Input Validation
**Severity:** Medium
**Confidence:** Medium

#### Complete Source-to-Sink Data Flow

**Source (Line 635):**
```typescript
app.get("/api/invoice/:invoiceId", moderateLimiter, async (req, res) => {
  // req.params.invoiceId is extracted from URL path
  // No validation applied
```

**Sanitization Check:** ❌ **NONE**
- No regex pattern validation for invoice ID format
- No allowlist of valid characters
- No path traversal sequence blocking (../, %2e%2e%2f, etc.)
- No URL encoding validation
- No length restriction
- No alphanumeric-only enforcement

**Sink (Lines 650-651):**
```typescript
const [invoiceRes, methodsRes] = await Promise.all([
  fetchWithRetry(
    `${BTCPAY_URL}/api/v1/stores/${BTCPAY_STORE_ID}/invoices/${req.params.invoiceId}`,
    { headers }
  ),
  fetchWithRetry(
    `${BTCPAY_URL}/api/v1/stores/${BTCPAY_STORE_ID}/invoices/${req.params.invoiceId}/payment-methods`,
    { headers }
  ),
]);
```

**URL Construction Analysis:**
- Base URL: `${BTCPAY_URL}` (environment variable - attacker cannot control)
- Path prefix: `/api/v1/stores/${BTCPAY_STORE_ID}/invoices/`
- **Tainted segment:** `${req.params.invoiceId}` (100% attacker-controlled)
- No URL encoding applied before interpolation

**Response Handling (Lines 654-682):**
```typescript
if (!invoiceRes.ok || !methodsRes.ok) {
  return res.status(404).json({ message: "Invoice not found" });
}

const invoice = await invoiceRes.json() as Record<string, unknown>;
const methods = await methodsRes.json() as Array<{...}>;

// Structured data from external service returned to attacker
res.json({
  id: invoice.id,
  amount: invoice.amount,
  currency: invoice.currency,
  status: invoice.status,
  expirationTime: invoice.expirationTime,
  createdTime: invoice.createdTime,
  metadata: invoice.metadata,
  paymentMethods: methods.map((m) => ({ /* ... */ })),
});
```

**Information Disclosure:** ✅ HIGH
- Response body from BTCPay Server is parsed and returned to the attacker
- Structured invoice data is extracted and exposed
- Error messages could leak timing information

#### Exploitation Constraints

**What Limits Exploitation:**

1. **Express.js URL Normalization:** Express normalizes URL paths before routing, which means classic path traversal sequences like `../../` are resolved at the HTTP layer before reaching the application code. Testing confirmed that `/api/invoice/../../test` is normalized to `/test` by the web server.

2. **Pre-configured Base URL:** The `BTCPAY_URL` is controlled by environment variables and cannot be modified by the attacker through this endpoint. All requests must go to the configured BTCPay Server instance.

3. **URL Template Structure:** The invoiceId is embedded in the middle of the URL path, not at the beginning or end, which limits the ability to completely redirect the request.

4. **Rate Limiting:** 30 requests per 15 minutes slows enumeration attacks.

**What Exploitation Could Achieve:**

1. **BTCPay Server Endpoint Enumeration:** While path traversal may be normalized, the attacker can still provide different invoice IDs to probe for valid endpoints or test different API paths within the BTCPay Server API structure.

2. **Information Disclosure:** By providing various invoice IDs (including potentially guessable formats), an attacker could:
   - Enumerate valid invoice IDs
   - Access invoice data for other customers
   - Retrieve payment method details and cryptocurrency addresses
   - Extract metadata that might contain sensitive information

3. **API Abuse:** Depending on BTCPay Server's API design, manipulating the invoiceId could potentially:
   - Access administrative API endpoints (if invoice ID format can be manipulated to match other endpoint patterns)
   - Trigger different API behaviors
   - Cause denial of service through malformed requests

#### Proof of Concept

**Basic Test (Safe):**
```http
GET /api/invoice/nonexistent123 HTTP/1.1
Host: exogenous.fun

Response: {"message":"Invoice not found"} (404)
```

**Validation:**
- Request successfully reaches the BTCPay Server
- Server processes the invoice ID and returns a response
- No input validation prevents arbitrary strings in the invoice ID parameter

#### Missing Defenses

**At Input Layer:**
- ❌ No invoice ID format validation (should match expected format like alphanumeric with specific length/pattern)
- ❌ No character allowlist (should only accept [a-zA-Z0-9-_])
- ❌ No path traversal sequence detection

**At HTTP Client Layer:**
- ❌ No URL validation before making request
- ❌ No destination allowlist
- ❌ No protocol restriction

**At Response Layer:**
- ⚠️ Generic error messages (good) but timing differences could leak information
- ⚠️ Full response body disclosure (necessary for functionality but increases information exposure)

#### Remediation Recommendations

**Immediate (High Priority):**
```typescript
// Validate invoice ID format before use
const invoiceIdPattern = /^[a-zA-Z0-9_-]{1,64}$/;
if (!invoiceIdPattern.test(req.params.invoiceId)) {
  return res.status(400).json({ message: "Invalid invoice ID format" });
}
```

**Defense in Depth (Medium Priority):**
```typescript
// Add URL validation in fetchWithRetry
function validateURL(url: string): boolean {
  try {
    const parsed = new URL(url);
    // Only allow requests to configured BTCPay server
    if (!BTCPAY_URL || !url.startsWith(BTCPAY_URL)) {
      return false;
    }
    // Ensure HTTPS protocol
    if (parsed.protocol !== 'https:') {
      return false;
    }
    return true;
  } catch {
    return false;
  }
}
```

## 6. Secure by Design: Validated Components

The following components were analyzed and found to have robust defenses against SSRF attacks. They represent secure design patterns that should be maintained.

| Component/Flow | Endpoint/File Location | Defense Mechanism Implemented | Verdict |
|----------------|------------------------|------------------------------|---------|
| Checkout Invoice Creation | `POST /api/checkout` (routes.ts:478-633) | ✅ Destination URL entirely controlled by environment variables<br/>✅ No user input in URL construction<br/>✅ Payment method validated against strict allowlist<br/>✅ All prices calculated server-side<br/>✅ Strict rate limiting (10 req/15min) | **SAFE** |
| Product Retrieval | `GET /api/products/:slug` | ✅ Uses database ORM (Drizzle) with parameterized queries<br/>✅ No outbound HTTP requests made<br/>✅ Slug used only for database lookup | **SAFE** |
| Results Retrieval | `GET /api/results/:uid` | ✅ No outbound HTTP requests<br/>✅ Data served from local database<br/>✅ UID used only for database query | **SAFE** |
| Post Content Retrieval | `GET /api/posts/:slug` | ✅ No outbound HTTP requests<br/>✅ Database-only operation<br/>✅ ORM prevents SQL injection | **SAFE** |
| Static File Serving | `/uploads/*` | ✅ Uses Express static middleware<br/>✅ No dynamic URL construction<br/>✅ No outbound requests | **SAFE** |
| Admin Product Management | `POST/PUT/DELETE /api/admin/products/*` | ✅ No outbound HTTP requests<br/>✅ Database operations only<br/>✅ Requires authentication | **SAFE** |
| Test Result Creation | `POST /api/admin/results` (routes.ts:239-246) | ✅ No file operations at creation time<br/>✅ Data stored in database only<br/>✅ Chromatograms field stored as JSON text<br/>⚠️ Requires authentication | **SAFE** (at creation)<br/>**Note:** See admin file SSRF finding |

### Defense Patterns Observed

**Pattern 1: Environment-Controlled Destinations**
The POST /api/checkout endpoint demonstrates the gold standard for server-side HTTP requests:
- Destination URL is read from environment variables at server startup
- No user input contributes to the target URL
- Request headers and authentication are server-controlled
- Only request body payload contains (validated) user data

**Pattern 2: Database-First Architecture**
Most endpoints avoid SSRF entirely by not making outbound HTTP requests:
- Data is served from PostgreSQL database
- Drizzle ORM provides parameterized queries preventing injection
- No URL construction or network requests in request handlers

**Pattern 3: Input Validation at Entry Points**
Where user input is accepted, validation is applied:
- Payment method validated against allowlist: `["btc", "ltc", "xmr"]`
- Coupon codes validated against database records
- Product quantities checked for positive integers
- Shipping/service info validated with Zod schemas

## 7. Administrative Interface SSRF Analysis

### Authentication Testing Results

**Admin Login Endpoint:** `POST /api/admin/login`
**Status:** ✅ ENABLED on live system (https://exogenous.fun/admin)

**Credential Testing:**
- **Exposed Password:** `Ju%5uLB@98B*mPsRGDszSy9A` (found in `.replit` file, line 45)
- **Tested Usernames:** admin, administrator, root, supplements, exogenous, test
- **Results:** All authentication attempts failed with 401 Unauthorized
- **Rate Limiting:** 10 requests per 15 minutes (strict limiter)

**Conclusion:** Admin endpoints are NOT externally exploitable via credential guessing. The username is either:
1. Set to a non-standard value not tested
2. Never configured (though login page is enabled, suggesting it is configured)
3. Requires additional authentication factors

### Critical Admin Vulnerability (Not Externally Exploitable)

**Endpoint:** `POST /api/admin/migrate-images`
**File Location:** `/repos/exo/server/routes.ts:297-328`
**Vulnerability Type:** File-Based SSRF / Path Traversal
**Severity:** Critical (if authentication bypassed)
**External Exploitability:** ❌ NO (requires valid admin session)

#### Vulnerability Details

This endpoint contains a **critical file-based SSRF vulnerability** that would allow arbitrary file reads if an attacker gained admin access:

```typescript
app.post("/api/admin/migrate-images", requireAdmin, async (_req, res) => {
  const results = await storage.getTestResults();
  for (const result of results) {
    const chromatograms: string[] = JSON.parse(result.chromatograms || "[]");
    const updated = chromatograms.map((url) => {
      if (url.startsWith("/uploads/")) {
        const filePath = path.join(process.cwd(), url);  // ← PATH TRAVERSAL
        if (fs.existsSync(filePath)) {
          const fileBuffer = fs.readFileSync(filePath);  // ← FILE READ
          const mimeType = /* ... */;
          return `data:${mimeType};base64,${fileBuffer.toString("base64")}`;
        }
      }
      return url;
    });
    if (changed) {
      await storage.updateTestResult(result.id, { chromatograms: JSON.stringify(updated) });
    }
  }
```

**Attack Vector (if authenticated):**
1. Create test result: `POST /api/admin/results` with `chromatograms: ["/uploads/../../../etc/passwd"]`
2. Trigger migration: `POST /api/admin/migrate-images`
3. File is read, base64-encoded, and stored in database
4. Retrieve via `GET /api/results/{uid}` (public endpoint - no auth required!)

**Missing Defenses:**
- ❌ No path traversal validation
- ❌ No path normalization (`path.resolve()`)
- ❌ No check that resolved path is within `/uploads/` directory
- ❌ Only checks if string starts with `/uploads/` (easily bypassed)

**Exploitable Files:**
- `/etc/passwd` - System users
- `/proc/self/environ` - Environment variables (contains secrets!)
- `/.env` - Application configuration
- `/repos/exo/server/routes.ts` - Source code disclosure
- Any file readable by the Node.js process

**Recommendation:** Even though this is not externally exploitable currently, it should be fixed to prevent insider threats or post-compromise escalation:
```typescript
const uploadsDir = path.resolve(process.cwd(), 'uploads');
const resolvedPath = path.resolve(process.cwd(), url);
if (!resolvedPath.startsWith(uploadsDir)) {
  // Reject path traversal attempt
  return url;
}
```

## 8. Vectors Analyzed and Confirmed Secure

The following potential SSRF vectors were systematically analyzed and confirmed to be secure:

### URL Parameter Endpoints (No SSRF Risk)

| Endpoint | Parameter | Analysis Result |
|----------|-----------|-----------------|
| `GET /api/products/:slug` | slug | Database lookup only, no HTTP requests |
| `GET /api/posts/:slug` | slug | Database lookup only, no HTTP requests |
| `GET /api/results/:uid` | uid | Database lookup only, no HTTP requests |
| `GET /api/pages/:slug` | slug | Database lookup only, no HTTP requests |
| `POST /api/posts/:slug/unlock` | slug | Database query, no outbound requests |

### Form Submission Endpoints (No SSRF Risk)

| Endpoint | User Inputs | Analysis Result |
|----------|-------------|-----------------|
| `POST /api/checkout` | items, paymentMethod, shippingInfo, serviceInfo, couponCode | ✅ Destination hardcoded via env vars<br/>✅ No user input in URL construction<br/>✅ Payment method validated against allowlist |
| `POST /api/coupons/validate` | code, subtotal | Database lookup only, no HTTP requests |

### File Upload Endpoints (No Network SSRF)

| Endpoint | Functionality | Analysis Result |
|----------|---------------|-----------------|
| `POST /api/admin/upload` | Single file upload | ✅ Files stored as base64 in memory<br/>✅ No URL processing<br/>✅ No outbound requests |
| `POST /api/admin/upload-files` | Multiple file upload | ✅ Same as above<br/>✅ Authentication required |

### Image Processing (No External Fetching)

**Finding:** The application does NOT use any image processing libraries that could trigger SSRF:
- ❌ No sharp, jimp, ImageMagick, GraphicsMagick usage
- ✅ Images stored as base64 data URIs
- ✅ No image URL fetching functionality
- ✅ No thumbnail generation or remote image processing

### Webhook/Callback Endpoints (None Found)

**Finding:** The application does NOT implement:
- ❌ Webhook receivers
- ❌ Callback URL parameters
- ❌ OIDC/OAuth redirect URLs with user input
- ❌ RSS feed fetchers
- ❌ URL shortener/redirect functionality

### API Proxy Functionality (None Found)

**Finding:** No generic proxy endpoints exist:
- ❌ No `/proxy/*` routes
- ❌ No `/fetch/*` routes
- ❌ No URL passthrough functionality
- ✅ Only specific, hardcoded external service (BTCPay Server)

## 9. Exploitation Difficulty Assessment

### SSRF-VULN-01: GET /api/invoice/:invoiceId

**Exploitation Difficulty:** 🟡 MODERATE

**Factors Increasing Difficulty:**
1. **URL Normalization:** Express.js and browser-level URL normalization prevents classic path traversal attacks (../../)
2. **Fixed Base URL:** Cannot redirect to arbitrary hosts; must target BTCPay Server
3. **URL Structure:** Invoice ID is in the middle of the path, limiting manipulation options
4. **Rate Limiting:** 30 requests per 15 minutes slows reconnaissance
5. **Unknown BTCPay URL:** BTCPAY_URL not disclosed in source code

**Factors Decreasing Difficulty:**
1. **No Input Validation:** Any string accepted as invoice ID
2. **Unauthenticated Access:** No authentication required to access endpoint
3. **Full Response Disclosure:** Complete response body returned to attacker
4. **Information Leakage:** Error messages and timing can reveal valid vs invalid invoice IDs

**Realistic Exploitation Scenarios:**

**Scenario 1: Invoice Enumeration**
- **Likelihood:** HIGH
- **Method:** Submit sequential invoice IDs to enumerate valid invoices
- **Impact:** Access to other customers' payment information, cryptocurrency addresses, order metadata
- **Constraint:** Rate limiting (30/15min) makes large-scale enumeration slow

**Scenario 2: BTCPay API Reconnaissance**
- **Likelihood:** MEDIUM
- **Method:** Test various invoice ID formats that might map to other BTCPay API endpoints
- **Impact:** Discovery of additional API functionality, potential access to administrative endpoints
- **Constraint:** Requires knowledge of BTCPay Server API structure; URL normalization limits path manipulation

**Scenario 3: Timing-Based Information Disclosure**
- **Likelihood:** MEDIUM
- **Method:** Measure response times to differentiate between nonexistent invoices, valid invoices, and error conditions
- **Impact:** Leak information about system state, valid invoice ID patterns
- **Constraint:** Network latency variability may obscure timing differences

### Exploitation Prerequisites

**What an attacker needs:**
1. ✅ **Network access:** Internet connection to https://exogenous.fun (publicly accessible)
2. ✅ **No authentication:** Endpoint is publicly accessible
3. ⚠️ **Invoice ID knowledge:** May need to guess or enumerate valid formats
4. ⚠️ **BTCPay API knowledge:** Understanding of BTCPay Server API structure helps maximize impact

**What an attacker does NOT need:**
- ❌ Admin credentials
- ❌ User account
- ❌ Internal network access
- ❌ VPN or special tooling

### Expected Exploitation Impact

**Conservative Impact (High Confidence):**
- Enumeration of valid invoice IDs
- Access to invoice metadata for orders placed by other customers
- Disclosure of cryptocurrency payment addresses and amounts
- Information about payment methods and transaction status

**Optimistic Impact (Medium Confidence):**
- Access to additional BTCPay Server API endpoints via invoice ID manipulation
- Potential access to store-level configuration or statistics
- Reconnaissance for further attacks against the BTCPay Server

**Speculative Impact (Low Confidence):**
- If BTCPay Server has its own vulnerabilities, this SSRF could be chained
- Potential DoS by triggering expensive operations on BTCPay Server
- Access to administrative functions if BTCPay API authorization is weak

## 10. Methodology Application Summary

### Backward Taint Analysis Results

**SSRF Sink Identified:** 1 endpoint making outbound HTTP requests with user input
**Analysis Method:** Backward taint analysis from HTTP client calls to user input sources

| Sink | Source | Sanitization | Verdict |
|------|--------|--------------|---------|
| `fetchWithRetry()` at routes.ts:650 | `req.params.invoiceId` | **NONE** | ⚠️ VULNERABLE |
| `fetchWithRetry()` at routes.ts:651 | `req.params.invoiceId` | **NONE** | ⚠️ VULNERABLE |
| `fetchWithRetry()` at routes.ts:593 | Environment variables only | N/A | ✅ SAFE |

### SSRF Checklist Application

**1. HTTP Client Usage Patterns** ✅ COMPLETE
- Identified all files using HTTP clients (1 file: routes.ts)
- Traced all outbound requests (2 endpoints)
- Documented client library (native fetch API)

**2. Protocol and Scheme Validation** ❌ FAILED
- No protocol allowlisting found
- No dangerous scheme blocking (file://, gopher://, etc.)
- Verdict: Missing critical control

**3. Hostname and IP Address Validation** ❌ FAILED
- No hostname allowlisting
- No IP range blocklist (RFC 1918, link-local)
- No localhost/127.0.0.1 blocking
- Verdict: Missing critical control

**4. Port Restriction and Service Access Controls** ❌ FAILED
- No port restrictions
- No internal service port blocking
- No cloud metadata endpoint blocking (169.254.169.254)
- Verdict: Missing critical control (mitigated by environment-controlled base URL)

**5. URL Parsing and Validation Bypass Techniques** ⚠️ PARTIAL
- Express.js performs URL normalization (good)
- No application-layer encoding validation
- No URL injection character filtering
- Verdict: Partial protection from infrastructure, application layer weak

**6. Request Modification and Headers** ✅ PASS
- Sensitive headers (Authorization) are server-controlled
- No user control over request headers
- Custom headers cannot be injected via parameters
- Verdict: Secure

**7. Response Handling and Information Disclosure** ⚠️ PARTIAL
- Generic error messages (good)
- Full response body returned (necessary for functionality, increases exposure)
- No size limits observed
- Verdict: Acceptable for use case, but increases information disclosure risk

### Security Control Coverage

| Security Control | Status | Notes |
|------------------|--------|-------|
| Input validation on URL parameters | ❌ MISSING | Critical gap in GET /api/invoice/:invoiceId |
| Protocol allowlist (https:// only) | ❌ MISSING | No validation in fetchWithRetry() |
| Domain/hostname allowlist | ⚠️ PARTIAL | Base URL is environment-controlled but not validated |
| IP range blocklist | ❌ MISSING | No RFC 1918 or link-local blocking |
| Port restrictions | ❌ MISSING | Any port accessible if URL controlled |
| Path traversal prevention | ⚠️ PARTIAL | Express normalizes, but application doesn't validate |
| URL encoding validation | ❌ MISSING | No encoding/decoding checks |
| Rate limiting | ✅ PRESENT | 30 req/15min on vulnerable endpoint |
| Authentication on admin endpoints | ✅ PRESENT | requireAdmin middleware enforced |
| Response size limits | ❌ MISSING | No observed limits |

## 11. Recommendations and Remediation Roadmap

### Critical Priority (Immediate Action Required)

**1. Validate Invoice ID Format**
```typescript
// In GET /api/invoice/:invoiceId handler (before line 650)
const INVOICE_ID_PATTERN = /^[a-zA-Z0-9_-]{1,64}$/;
if (!INVOICE_ID_PATTERN.test(req.params.invoiceId)) {
  return res.status(400).json({ message: "Invalid invoice ID format" });
}
```
**Impact:** Prevents arbitrary string injection, blocks most SSRF attempts
**Effort:** Low (5 minutes)
**Risk Reduction:** High

**2. Harden fetchWithRetry with URL Validation**
```typescript
async function fetchWithRetry(url: string, options: RequestInit, retries = 3): Promise<Response> {
  // Validate URL before making request
  try {
    const parsed = new URL(url);

    // Enforce HTTPS only
    if (parsed.protocol !== 'https:') {
      throw new Error('Only HTTPS requests allowed');
    }

    // Allowlist expected domains
    const allowedDomains = [new URL(BTCPAY_URL || '').hostname];
    if (!allowedDomains.includes(parsed.hostname)) {
      throw new Error('Request to unauthorized domain');
    }

    // Block private IP ranges
    const hostname = parsed.hostname;
    if (
      hostname === 'localhost' ||
      hostname.match(/^127\./) ||
      hostname.match(/^10\./) ||
      hostname.match(/^172\.(1[6-9]|2[0-9]|3[0-1])\./) ||
      hostname.match(/^192\.168\./) ||
      hostname.match(/^169\.254\./)
    ) {
      throw new Error('Request to private IP range blocked');
    }
  } catch (err) {
    throw new Error(`URL validation failed: ${err.message}`);
  }

  // Original retry logic
  for (let i = 0; i < retries; i++) {
    try {
      return await fetch(url, options);
    } catch (err) {
      if (i === retries - 1) throw err;
      await new Promise((r) => setTimeout(r, 500 * (i + 1)));
    }
  }
  throw new Error("fetch failed after retries");
}
```
**Impact:** Defense-in-depth, prevents future SSRF if new code uses fetchWithRetry
**Effort:** Medium (30 minutes)
**Risk Reduction:** High

### High Priority (Within 1 Week)

**3. Fix Admin File-Based SSRF**
```typescript
// In POST /api/admin/migrate-images (line 297-328)
const UPLOADS_DIR = path.resolve(process.cwd(), 'uploads');

chromatograms.map((url) => {
  if (url.startsWith("/uploads/")) {
    const resolvedPath = path.resolve(process.cwd(), url);

    // Verify path is within uploads directory
    if (!resolvedPath.startsWith(UPLOADS_DIR)) {
      console.warn(`Path traversal attempt blocked: ${url}`);
      return url; // Return original, don't process
    }

    if (fs.existsSync(resolvedPath)) {
      // ... rest of logic
    }
  }
  return url;
});
```
**Impact:** Prevents file-based SSRF in admin interface
**Effort:** Low (10 minutes)
**Risk Reduction:** Medium (admin-only, but critical if authentication bypassed)

**4. Validate Environment Variables at Startup**
```typescript
// At server startup (index.ts or routes.ts top)
if (BTCPAY_URL) {
  try {
    const parsed = new URL(BTCPAY_URL);
    if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
      throw new Error('BTCPAY_URL must use HTTP or HTTPS protocol');
    }
    console.log(`✓ BTCPAY_URL validated: ${BTCPAY_URL}`);
  } catch (err) {
    console.error(`✗ Invalid BTCPAY_URL: ${err.message}`);
    process.exit(1);
  }
}
```
**Impact:** Prevents misconfiguration that could enable SSRF
**Effort:** Low (10 minutes)
**Risk Reduction:** Medium

### Medium Priority (Within 1 Month)

**5. Implement Response Size Limits**
```typescript
// In fetchWithRetry, after successful fetch
const MAX_RESPONSE_SIZE = 10 * 1024 * 1024; // 10 MB
if (response.headers.get('content-length')) {
  const size = parseInt(response.headers.get('content-length') || '0');
  if (size > MAX_RESPONSE_SIZE) {
    throw new Error('Response size exceeds limit');
  }
}
```

**6. Add Request Timeout Configuration**
```typescript
// In fetchWithRetry options
const response = await fetch(url, {
  ...options,
  signal: AbortSignal.timeout(30000), // 30 second timeout
});
```

**7. Implement Monitoring and Alerting**
- Log all outbound HTTP requests with destinations
- Alert on requests to unexpected domains
- Monitor for failed requests that could indicate SSRF attempts
- Track invoice ID patterns that fail validation

### Low Priority (Nice to Have)

**8. Enable HTTPS Strict Mode for Sessions**
```typescript
// In server/index.ts session config
cookie: {
  secure: process.env.NODE_ENV === 'production', // Force HTTPS in production
  httpOnly: true,
  sameSite: 'strict', // Upgrade from 'lax'
}
```

**9. Implement Content Security Policy**
- Add CSP headers to prevent data exfiltration via client-side SSRF

**10. Regular Security Audits**
- Review all new endpoints that make HTTP requests
- Audit environment variable configuration regularly
- Test SSRF defenses with automated scanners

## 12. Conclusion

### Summary of Findings

This analysis identified **one medium-severity SSRF vulnerability** in the invoice retrieval endpoint (`GET /api/invoice/:invoiceId`). While the vulnerability exists at the code level with completely absent input validation, practical exploitation is constrained by:

1. Express.js URL normalization preventing classic path traversal
2. Environment-controlled base URL limiting destination manipulation
3. Rate limiting slowing enumeration attacks

The most realistic exploitation scenario is **invoice enumeration and information disclosure** - an attacker could submit various invoice IDs to access payment information for other customers' orders.

### Positive Security Observations

The application demonstrates several good security practices:
- Most endpoints avoid SSRF by not making outbound HTTP requests
- Checkout flow uses environment-controlled destinations exclusively
- Admin endpoints are properly protected by authentication
- Rate limiting is implemented on sensitive endpoints
- Database queries use ORM with parameterized queries

### Key Takeaway

The primary security gap is the **absence of defense-in-depth** for outbound HTTP requests. While current code paths have limited SSRF risk due to architectural constraints, the lack of validation at both the input layer and HTTP client layer creates risk for future development. Implementing the recommended validations will provide robust protection against both current and future SSRF vulnerabilities.

### External Exploitability Verdict

**GET /api/invoice/:invoiceId** - ✅ **EXTERNALLY EXPLOITABLE**
- Accessible via public internet without authentication
- Can be exploited to enumerate invoice data and potentially probe BTCPay Server API
- Recommend inclusion in exploitation queue with Medium confidence

**Admin Endpoints** - ❌ **NOT EXTERNALLY EXPLOITABLE**
- Require valid admin authentication
- Exposed password in .replit file did not work with common usernames
- File-based SSRF exists but cannot be accessed from external network
- Recommend exclusion from exploitation queue

---

**Analysis Completed:** 2026-03-01
**Analyst:** Claude Code SSRF Analysis Specialist
**Application:** exogenous.fun supplement testing shop
**Vulnerabilities Identified:** 1 externally exploitable SSRF
**Exploitation Queue Entries:** 1

