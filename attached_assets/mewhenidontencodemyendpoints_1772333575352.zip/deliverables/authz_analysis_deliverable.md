# Authorization Analysis Report

## 1. Executive Summary

- **Analysis Status:** Complete
- **Key Outcome:** Three high-confidence authorization vulnerabilities identified and documented. All findings are externally exploitable via https://exogenous.fun/ without requiring internal network access.
- **Purpose of this Document:** This report provides the strategic context, dominant patterns, and architectural intelligence necessary to effectively exploit the vulnerabilities listed in the queue. It is intended to be read alongside the JSON deliverable.

## 2. Dominant Vulnerability Patterns

### Pattern 1: Missing Ownership Validation (Horizontal Privilege Escalation)
- **Description:** Multiple public-facing endpoints accept resource identifiers (UID, invoiceId, slug) without validating that the requesting user owns or has legitimate access to those resources. There is no session-to-resource linkage, no user authentication requirement, and no ownership checks before returning sensitive data.
- **Implication:** Any anonymous user can access sensitive data belonging to other users by simply knowing or enumerating the resource identifier. This includes medical test results with PII, payment invoices with financial data, and hidden products intended for admin-only access.
- **Representative Vulnerabilities:** AUTHZ-VULN-01 (test results), AUTHZ-VULN-02 (invoices)

### Pattern 2: Incomplete Vertical Access Controls (Admin Content Leakage)
- **Description:** The application inconsistently enforces admin-only access to certain content types. While admin modification endpoints are properly protected, some read endpoints bypass the visibility filters that should restrict content to administrators.
- **Implication:** Anonymous users can access resources explicitly marked as hidden by administrators, undermining the purpose of admin content management controls.
- **Representative Vulnerabilities:** AUTHZ-VULN-03 (hidden products)

## 3. Strategic Intelligence for Exploitation

### Session Management Architecture
- **Session Technology:** Express-session with PostgreSQL storage (connect-pg-simple)
- **Session Scope:** Sessions are ONLY used for admin authentication - there is no user registration or user session management
- **Critical Finding:** The application operates under a "stateless public access" model where anonymous users can access most endpoints without any session or authentication. This design decision creates a fundamental architecture where authorization checks are absent by default rather than by oversight.

### Role/Permission Model
- **Roles Identified:** Two roles only - `anon` (anonymous/public) and `admin` (authenticated administrator)
- **Role Storage:** Admin status stored as boolean flag `req.session.isAdmin` in PostgreSQL session store
- **Admin Protection:** `requireAdmin` middleware exists at server/routes.ts:36-41 and is correctly applied to 24 administrative endpoints
- **Critical Finding:** The binary role model (admin vs anonymous) means there is no concept of "users" with individual permissions. All public endpoints treat all callers as equivalent anonymous users with no identity tracking.

### Resource Access Patterns
- **Identifier Types:**
  - `uid` - Test result unique identifiers (format: short alphanumeric strings, e.g., "R-12345")
  - `invoiceId` - BTCPay Server invoice IDs (format: varies, typically alphanumeric)
  - `slug` - Human-readable URL slugs for products, posts, and pages (format: lowercase-with-hyphens)
  - `id` - Numeric database primary keys for admin operations
- **Critical Finding:** All public endpoints accept identifiers as URL parameters with ZERO validation of:
  - Whether the identifier was legitimately obtained by the caller
  - Whether the caller has any relationship to the resource
  - Whether the resource should be publicly accessible
- **Database Query Pattern:** All vulnerable endpoints use simple SELECT WHERE statements with no user/session filtering (e.g., `SELECT * FROM test_results WHERE uid = ?`)

### Data Isolation Architecture
- **No Multi-Tenancy:** The application is single-tenant with no organizational boundaries
- **No User Accounts:** There is no user registration, login, or profile system for customers
- **Order Tracking:** Orders are created with a random `orderUid` but have NO linkage to user sessions or identities
- **Critical Finding:** The absence of user accounts means there is fundamentally no concept of "data ownership" in the application architecture. Orders, test results, and invoices are essentially public database records with pseudo-random identifiers as the only "access control."

### Workflow Implementation
- **Checkout Flow:** POST /api/checkout creates orders without session association
  - Returns `orderUid` and `invoiceId` to client
  - No server-side tracking of which session/user created which order
  - Invoice viewing requires only the `invoiceId` with no ownership validation
- **Test Results Flow:** Admin creates results via POST /api/admin/results
  - Optional `orderUid` field links results to orders (no validation that orderUid exists)
  - Results accessible via `uid` with no authentication
  - No mechanism to restrict results to the customer who placed the order
- **Critical Finding:** All workflows assume that knowledge of the identifier (orderUid, invoiceId, uid) is sufficient "proof" of authorization. This is security by obscurity, not access control.

## 4. Vectors Analyzed and Confirmed Secure

These authorization checks were traced and confirmed to have robust, properly-placed guards. They are **low-priority** for further testing.

| **Endpoint** | **Guard Location** | **Defense Mechanism** | **Verdict** |
|--------------|-------------------|----------------------|-------------|
| `POST /api/checkout` | server/routes.ts:478-633 | Server-side price calculation, product validation, stock checks - ignores client-submitted prices | SAFE |
| `POST /api/admin/logout` | server/routes.ts:137-141 | Session.destroy() only affects caller's own session, cannot harm other users | SAFE |
| `GET /api/admin/check` | server/routes.ts:143-145 | Returns only caller's own session status, no sensitive data leakage | SAFE (informational) |
| `POST /api/admin/products` | server/routes.ts:152 | requireAdmin middleware properly applied before handler | SAFE |
| `PATCH /api/admin/products/:id` | server/routes.ts:161 | requireAdmin middleware properly applied before handler | SAFE |
| `DELETE /api/admin/products/:id` | server/routes.ts:173 | requireAdmin middleware properly applied before handler | SAFE |
| `GET /api/admin/posts` | server/routes.ts:181 | requireAdmin middleware properly applied before handler | SAFE |
| `POST /api/admin/posts` | server/routes.ts:186 | requireAdmin middleware properly applied before handler | SAFE |
| `PATCH /api/admin/posts/:id` | server/routes.ts:198 | requireAdmin middleware properly applied before handler | SAFE |
| `DELETE /api/admin/posts/:id` | server/routes.ts:210 | requireAdmin middleware properly applied before handler | SAFE |
| `GET /api/admin/results` | server/routes.ts:234 | requireAdmin middleware properly applied before handler | SAFE |
| `POST /api/admin/results` | server/routes.ts:239 | requireAdmin middleware properly applied before handler | SAFE |
| `PATCH /api/admin/results/:id` | server/routes.ts:248 | requireAdmin middleware properly applied before handler | SAFE |
| `DELETE /api/admin/results/:id` | server/routes.ts:260 | requireAdmin middleware properly applied before handler | SAFE |
| `POST /api/admin/upload` | server/routes.ts:268 | requireAdmin middleware properly applied before handler | SAFE |
| `POST /api/admin/upload-files` | server/routes.ts:281 | requireAdmin middleware properly applied before handler | SAFE |
| `POST /api/admin/migrate-images` | server/routes.ts:297 | requireAdmin middleware properly applied before handler | SAFE |
| `PUT /api/admin/pages/:slug` | server/routes.ts:338 | requireAdmin middleware properly applied before handler | SAFE |
| `GET /api/admin/orders` | server/routes.ts:347 | requireAdmin middleware properly applied before handler | SAFE |
| `GET /api/admin/analytics` | server/routes.ts:352 | requireAdmin middleware properly applied before handler | SAFE |
| `GET /api/admin/coupons` | server/routes.ts:413 | requireAdmin middleware properly applied before handler | SAFE |
| `POST /api/admin/coupons` | server/routes.ts:418 | requireAdmin middleware properly applied before handler | SAFE |
| `PATCH /api/admin/coupons/:id` | server/routes.ts:427 | requireAdmin middleware properly applied before handler | SAFE |
| `DELETE /api/admin/coupons/:id` | server/routes.ts:439 | requireAdmin middleware properly applied before handler | SAFE |
| `GET /api/products` | server/routes.ts:75-79 | Properly filters to only return products where isHidden=false | SAFE |
| `GET /api/posts` | server/routes.ts:89-93 | Returns all posts but strips lockPassword field | SAFE |
| `GET /api/posts/:slug` | server/routes.ts:95-105 | Returns empty content for locked posts, requires unlock workflow | SAFE |
| `POST /api/posts/:slug/unlock` | server/routes.ts:107-122 | Password validation before returning content, rate limited | SAFE (weak brute-force protection but authorization logic sound) |

## 5. Analysis Constraints and Blind Spots

### External Service Dependencies
- **BTCPay Server Integration:** The application integrates with an external BTCPay Server for cryptocurrency payment processing. Authorization checks within BTCPay Server itself could not be analyzed. The SSRF vulnerability in `/api/invoice/:invoiceId` could potentially be used to probe BTCPay Server's internal API, but this was not tested as it falls outside the scope of authorization analysis.

### Dynamic Identifier Generation
- **Unpredictable UIDs:** Test result UIDs and order UIDs are generated with formats that appear semi-random (e.g., "R-12345", "ORD-ABC123"). The predictability of these identifiers affects the practical exploitability of IDOR vulnerabilities but does not change their authorization status. Static analysis cannot definitively determine if UIDs are guessable without runtime testing.

### Database Constraints
- **Referential Integrity:** The database schema was analyzed through the Drizzle ORM schema definition. However, there may be database-level constraints (foreign keys, triggers) that were not visible in the application code. The analysis assumes that the application layer is the primary enforcement point for authorization, which appears to be the case based on the ORM usage patterns.

### Client-Side Validation
- **UI-Level Controls:** The client-side React application may implement additional visibility controls or restrictions that were not analyzed. As per authorization analysis methodology, client-side controls are not considered security boundaries and were not evaluated. All findings are based on server-side code paths.

### Rate Limiting Effectiveness
- **IP-Based Rate Limits:** The application uses express-rate-limit with default configuration, which typically implements IP-based rate limiting. The effectiveness of these limits against distributed attacks or attacks from behind proxies/VPNs could not be determined through static analysis. Rate limits are noted but not considered authorization controls.

### Workflow State Validation Edge Cases
- **Order Status Transitions:** Orders have a `status` field in the database, but the analysis did not trace all possible state transition logic. There may be edge cases where order status affects authorization that were not discovered.
- **Payment Completion Timing:** The relationship between invoice payment status and test result access was not fully traced. It's unclear if test results should only be accessible after payment is confirmed, as no such authorization logic was found in the code.

